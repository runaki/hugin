# Design

<!-- impeccable:design derived-from-build -->

Visual world of **Hugin ao Vivo** (`hugin-demo.html`). Recorded from the shipped build. Single committed dark world (PicPay-faithful + Hugin/raven accent). No light theme by choice.

## World

A near-black, green-biased "control room" for an autonomous support agent, shown at two altitudes of one product: a live ops dashboard (macro) and one agent instance working a case (micro). PicPay green is the *living* color — reserved for thought, pulse, data, and the one primary action — never spread as flat fill. Teal and amber are data/risk semantics, not brand accents.

## Color tokens

- `--bg #06100b` · `--bg2 #081610` · `--panel #0b1a12` · `--panel-2 #0e2117` — grounds, green-biased near-black.
- `--fg #e9f5ec` · `--muted #86a594` · `--muted-2 #5f7d6c` — text; secondary tinted from the green hue, never neutral gray.
- `--green #21c25e` (PicPay) · `--green-bright #35e27a` (glow/thought) · `--green-deep #0f6b37`.
- `--teal #3bd6c6` (data/transactions/tools) · `--amber #f2b33d` (risk/fraud/attention) · `--red #ff6b6b` · `--violet #9d8cff` (knowledge base).
- `--line` / `--line-2` — hairline borders as low-alpha green, not gray.
- `--glow rgba(53,226,122,.55)` — the one glow color (shadows carry blur, never zero-offset halos except intentional node bloom).

## Type

- Display / big numbers: **Sora** (700/600), tracking −.03/−.04em.
- UI / body: **Hanken Grotesk**.
- Telemetry (timestamps, latency, counts, retrieval ids): **JetBrains Mono** with `tabular-nums` — mono used for measurement only, never as costume.

## Iconography

Authored inline stroke SVGs (`ICONS` map), 24-grid, stroke 1.8, round caps, one weight. No emoji/unicode as icons. The **Hugin raven** is an authored filled emblem (`ravenSVG` / `drawRavenGlyph`) — front-view spread-wing Norse mark; it is the brand lockup, the agent avatar, and the glowing core of the memory graph.

## Layout

App shell: sticky chrome bar (raven wordmark + stage switch + live/clock/DEMO badge + reduce-motion) over two absolutely-stacked scenes that cross-dive with a scale+blur camera transition and a green scan flash. Each scene is an internal grid of `.panel`s that scroll in place; the page itself does not scroll on desktop.

- **Stage 1 (exec):** 4 live KPI tiles → real-time volume area chart (hero) + live themes bars (rank-animated) · event feed stream + active-instances constellation with the primary CTA.
- **Stage 2 (agent):** customer profile + case trail · status pill + conversation (typed) + reasoning stream + tool chips · memory graph (canvas, nodes ignite on consult) + retrieval readout with relevance bar.

## Motion (signature)

Refined/executive register (user redirect from the initial "full cinematographic"): glows, particle field and grain removed; flat fills, hairline strokes, desaturated green. What stays, all canvas/compositor-driven: continuous scrolling telemetry (sum-of-sines, not reshuffled data) and the signature memory graph — nodes brighten on consult, edges strengthen, and a small pulse travels core→node on each `consult`/`tool`, synced to the agent's status and streamed reasoning. Camera transition is a gentle crossfade (slight scale + light blur), no scan flash. `prefers-reduced-motion` and the in-UI toggle calm it further.

## Memory graph (real mode)

Drawn by `hugin-graph.js` (force-graph canvas) inside the "Grafo de memória" panel when the server is up. Layout is a fixed left-to-right tree with elbow connectors and labels beside the nodes — no physics; a force layout was rejected by the user (2026-10-07) as hard to read and always moving. Every mark encodes state, never decoration:

- Color = kind: tema `--green`, problema `--teal`, causa `--amber`, regra `--violet`.
- Filled = anchor, focus, trail or bridge (what the conversation is standing on). Outlined with a faint fill = a neighbor that got in by priority score.
- Dashed link = curated relation with no real count. Solid link = real complaint count.
- Faded with a slash = hypothesis checked and discarded. Extra ring = cause confirmed / case closed. Faded tema = previous theme kept as context.
- Dashed pill "+N" = what that node still hides; fixed screen size so it stays readable at any zoom.
- Activation is a ring that opens once and a dot that travels the link. No glow.
- Chrome around the canvas: theme breadcrumb top-left (previous themes struck through), kind/line legend bottom-left, visible-of-total count in the header.

## Honesty

All customers, conversations, volumes, themes, and metrics are **synthetic demo data**, labeled in-UI ("Dados de demonstração"). Replace with real telemetry before any external use. No real PII, no real PicPay figures, no backend.
