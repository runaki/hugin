# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

delegated: single self-contained interactive HTML artifact (scripted simulation, no backend). Chosen because the deliverable is a sales/demo piece that must "feel alive" and travel as one file in front of executives.

## Users

Primary viewers: PicPay executives and decision-makers in a demo/pitch setting. They are not operating the agent — they are being shown its potential. Secondary mental model: the real end-users of Hugin are PicPay customers in support, and the real operators are support/ops teams; the demo dramatizes both.

## Product Purpose

Hugin is an autonomous customer-service agent for PicPay (name = Huginn, Odin's raven of thought + "hug" + intelligence). The product itself works; this deliverable is the FRONTEND that sells the product — making executives feel the potential of a modern AI agent at scale. Success = executives leave convinced Hugin is real, capable, and worth investing in.

## Positioning

A single surface that shows an autonomous agent at two altitudes at once: the macro (an executive live-ops dashboard — volumes, themes, resolution trending in real time) and the micro (one agent instance working a real case: customer profile, live conversation, and a memory graph that lights up each node as it is consulted, synced to the agent's thinking and tool execution). The memory-graph-reacting-to-thought is the signature the category default (a static chat window or a flat BI dashboard) cannot copy.

## Operating Context

Shown on a large screen in a pitch/boardroom, or sent as a link. Runs itself in a loop with no operator input (auto-playing scripted simulation), but is navigable between the two stages on demand. Portuguese (pt-BR) throughout — Brazilian audience, PicPay domain.

## Capabilities and Constraints

- Two navigable stages in one artifact: (1) Executive live dashboard; (2) Live agent operation screen.
- Stage 2 must show: customer profile, the conversation, and a memory/knowledge graph whose nodes illuminate as they are consulted, in sync with the agent's reasoning and tool-execution stream.
- Charts and figures must update "live" (animated loop), evoking a real system running — reference: live-telemetry / agent-playing-a-game demos.
- Customers, conversations, tool results and the executive dashboard are SYNTHETIC and must be labeled as demo data; nothing may be fabricated as genuine.
- The memory graph is REAL (since 2026-10-07): a MongoDB knowledge base built from public sources, served by `server/`, with a server-side prioritization rule and theme-shift detection. See `docs/grafo-real.md`. It must show its source per node and mark curated links as such.
- The graph must never dump the base on screen: only the prioritized subgraph is visible (top-K per node, hard cap, everything else behind "+N").
- No real PII, no impersonation of real PicPay customers.

## Brand Commitments

- Name: Hugin. Raven-of-thought (Huginn) concept is a binding part of the identity.
- Visual world (brief-pinned): PicPay-faithful — near-black dark UI, PicPay green (#21C25E family) as the live/energy/thinking color — with a subtle Hugin/Norse accent (the raven as the agent's mark). Executives must recognize PicPay immediately.
- Motion register (user redirect, 2026-10-04): clean and executive — no glow, no particles, flat fills; the earlier "full cinematographic" register was rejected as "muito tech".

## Evidence on Hand

- Real, public: consumidor.gov.br open data (Senacon/MJSP), "Serviços Financeiros", September 2026 — 207,483 complaints, 5,509 naming PicPay; PicPay's public help-center article on failed Pix (8 causes, verbatim); Banco Central Pix regulations. All loaded in the memory graph with per-node source.
- Synthetic: every customer, conversation, tool result, and the executive dashboard's volumes, themes and metrics. Replace with real telemetry before any external/public use.

## Product Principles

- Prove, don't claim: dramatize the agent doing its job, not bullet points about it.
- Two altitudes, one system: macro dashboard and micro agent view must read as the same product.
- The thinking is the show: the memory graph and reasoning stream are the signature, reacting live.
- Credible, not sci-fi parody: cinematic but grounded in a real fintech product.
- Honest synthetic: everything invented is labeled demo data.

## Accessibility & Inclusion

Respect prefers-reduced-motion (offer a calmer state); maintain legible contrast on the dark ground despite heavy motion; pt-BR copy.
