# Hugin — card "Grafo de memória": pacote de porte

Este README foi escrito para um assistente de IA que vai ajudar um desenvolvedor de frontend a levar este card para o produto. Se você é esse assistente, leia até o fim antes de abrir os outros arquivos: aqui está o que é a tarefa, o que já foi decidido e por quê, e como saber que terminou.

## O que você tem em mãos

Uma implementação de referência que funciona de ponta a ponta. Não é um mock estático: há um servidor com MongoDB, uma base de dados pública real e um módulo de frontend que desenha e anima o resultado.

O Hugin é um agente autônomo de atendimento do PicPay. O card mostra, durante um atendimento, o que o agente consulta na base de conhecimento: em que tema a conversa está, que problema o cliente citou, que causas o agente verificou e qual confirmou. Quem assiste são executivos, numa demonstração; por isso o card precisa ser legível de longe e ficar parado quando nada está acontecendo.

## A tarefa

Portar o card para o frontend do produto, no stack que o desenvolvedor usa, mantendo o comportamento da referência.

O desenvolvedor vai dizer qual é o stack e onde o card entra. Pergunte se ele não disser. Duas coisas mudam bastante o trabalho e só ele sabe:

- se o backend deste pacote (`server/`) será usado como está, adaptado, ou reescrito por outra equipe;
- se ele quer manter o desenho em canvas ou reescrever em SVG/DOM (o guia cobre os dois caminhos, seção 16).

## O que é "pronto"

O card portado passa no checklist da seção 18 de `docs/GUIA-DE-PORTE.md`. Em resumo:

- mostra os quatro estados (vazio, sem pista, hipóteses, grafo) a partir do que a API devolve;
- desenha os dois layouts, **árvore** (padrão) e **rede**, e troca entre eles sem refazer a conversa;
- anima só o que acabou de acontecer, e fica imóvel depois;
- nunca mostra mais nós do que a API mandou, nem esconde algum por conta própria.

Compare com a referência rodando. As imagens em `docs/img/` mostram o alvo de cada estado.

## Ordem de leitura

1. **Este README.**
2. **`docs/GUIA-DE-PORTE.md`**: o documento principal. Construção do card, estados, vocabulário visual, animação com tempos exatos, os dois layouts com algoritmo e constantes, comportamento evento por evento, caminhos de porte, checklist e armadilhas.
3. **`hugin-graph.js`** (cerca de 390 linhas): o módulo a portar. Leia inteiro; é curto e comentado.
4. **`docs/grafo-real.md`**: contrato completo da API, modelo no MongoDB, regra de priorização e origem dos dados. Consulte quando precisar de um campo ou de uma regra do servidor.
5. **`hugin-demo.html`**: a página de referência. Interessa o bloco marcado `grafo real (MongoDB)`: `initReal`, `onRealStep`, `onRealView` e o roteiro `SCEN_REAL`. O resto do arquivo é a demo em volta do card.
6. **`server/rank.mjs`** e **`server/rank.test.mjs`**: a regra que decide o que aparece. Só é necessário se o backend for alterado.

`DESIGN.md` e `PRODUCT.md` dão o contexto visual e de produto.

## Como rodar

Requer Node 20 ou mais novo.

```bash
cd server
npm install
npm start            # http://localhost:4777  → aba "Atendimento ao vivo"
npm test             # 13 testes da regra; não precisam de MongoDB
```

Sem configuração, `npm start` baixa e sobe um MongoDB 7 efêmero (pacote `mongodb-memory-server`). O download tem cerca de 590 MB e acontece uma vez; o banco leva de 15 a 20 segundos para ficar pronto. Para usar um MongoDB existente: `MONGODB_URI="..." npm start`.

A página roda dois atendimentos em sequência. O primeiro cliente chega sem contexto (o card vai de "sem pista" a "hipóteses" e só então abre o grafo). O segundo começa falando da fatura do cartão e revela que o problema é o Pix (mudança de tema). O seletor **Árvore | Rede** fica no canto do card.

Abrir `hugin-demo.html` direto do disco não mostra o card real: sem a API, a página cai numa simulação antiga com outro grafo. Use sempre `http://localhost:4777`.

## Decisões já tomadas

Estas decisões vieram de rodadas de revisão com o dono do produto. Trate-as como requisitos. Se o desenvolvedor pedir algo que as contrarie, avise antes de mudar.

**O servidor decide o que aparece; o card decide como aparece.** O card desenha exatamente a `view` que recebe. Ele não filtra, não reordena por relevância e não conhece a base inteira. A regra de priorização fica num lugar só, com testes.

**Layout fixo, sem física.** Uma versão com layout de força foi construída e rejeitada: os nós não paravam de se mexer e os rótulos ficavam pequenos ("ficou muito ruim de ler", "fica se mexendo, ruim de acompanhar"). A posição de cada nó sai de uma função determinística (`layout()` e `layoutRede()`). O `force-graph` está no projeto só como canvas com zoom e clique; a simulação está desligada.

**Nada de brilho.** Uma primeira versão "cinematográfica", com glow e partículas, também foi rejeitada ("muito tech com os brilhos"). O destaque de um nó é feito com forma e opacidade: um anel que se abre, um ponto que viaja pelo conector, um nó riscado, um nó apagado. Não use `shadowBlur`, gradiente em texto nem partículas.

**Um nó que já está na tela não muda de lugar.** Irmãos ficam na ordem em que apareceram, não na ordem da nota. A câmera mantém o canto superior esquerdo fixo e só altera o zoom quando o desenho deixa de caber, quando sobra mais de 15% de espaço ou quando o tema muda.

**Árvore é o padrão; rede é a alternativa.** A árvore foi aprovada. A rede (camadas por tipo de nó, como um diagrama de rede neural) foi pedida como segunda proposta e convive com a árvore por um seletor. Mantenha as duas.

**Linha tracejada significa "sem contagem real".** A base junta três fontes públicas. As poucas ligações entre elas são curadoria e aparecem tracejadas. Esse código visual é o que mantém o card honesto; não o reaproveite para outra coisa.

**Antes do grafo, o card mostra hipóteses.** Quando o cliente não deu contexto, o card não inventa um tema: mostra o mapa geral ou as hipóteses com nota, e o agente pergunta. Só entra no grafo quando uma hipótese vence com margem.

## O que é real e o que é roteiro

| Parte | Estado |
|---|---|
| Base de conhecimento, MongoDB, busca, regra de priorização, mudança de tema | Real |
| O grafo, o painel de detalhe e a trilha do caso | Real: mostram o que a API devolveu |
| Falas do cliente e do agente, resultados das ferramentas | Roteiro, com clientes fictícios |
| A escolha de qual nó o agente visita | Roteiro. No produto, o agente decide |
| Visão executiva (KPIs, volume, eventos) | Simulação |

A base usa dados públicos: reclamações do consumidor.gov.br (setembro de 2026), um artigo da Central de Ajuda do PicPay e normativos do Banco Central. O painel mostra contagens do próprio PicPay ("28 do PicPay"). Os termos de uso dessas fontes não foram verificados para uso externo; o desenvolvedor deve saber disso antes de publicar qualquer coisa fora de uma demonstração interna.

## A API em uma tela

```
POST /api/consult  { sessionId?, text, hints? }    o cliente falou ('' = chegou sem dizer nada)
POST /api/visit    { sessionId, nodeId, status? }   o agente ou um clique foi até um nó
GET  /api/meta                                      regra, fontes e tamanho da base
```

As duas rotas `POST` devolvem `{ sessionId, view, trace, shift }`:

- `view`: o subgrafo que deve estar na tela agora, com `state` (`frio`, `hipoteses`, `ancorado`), `nodes`, `links`, `mesh`, `stats`.
- `trace`: a ordem em que os nós acendem neste passo.
- `shift`: preenchido quando a conversa mudou de tema.

Os tipos completos estão na seção 8 do guia.

## O módulo em uma tela

```js
import { mountMemoryGraph } from './hugin-graph.js';

const grafo = await mountMemoryGraph(el, { onStep, onView, mode: 'arvore' });

await grafo.consult('');                                     // chegou sem dizer nada
await grafo.consult('não consigo pagar a fatura do cartão');
await grafo.visit('pix:nao-concluido');                      // o agente abriu um nó
await grafo.visit('pix:saldo-insuficiente', 'descartado');   // ...e registrou o que achou
grafo.setMode('rede');
```

Cada chamada resolve depois que a animação da trilha terminou, e as chamadas são enfileiradas. As duas propriedades são usadas pela página e devem sobreviver ao porte.

## Como verificar o seu trabalho

Abra a referência e o card portado lado a lado e dirija os dois com a mesma sequência. Esta cobre todos os estados:

```js
await grafo.reset();
await grafo.consult('');                                   // sem pista: mapa geral
await grafo.consult('não tô conseguindo pagar');           // hipóteses com nota
await grafo.consult('é a fatura do cartão de crédito');    // entra no grafo
await grafo.visit('prob:nao-envio-atraso-do-boleto-ou-fatura-dificuldade-com-o-p');   // abre portas, entre elas o Pix
await grafo.consult('Tô tentando pagar por Pix, pelo app, e aparece transação não concluída');   // mudança de tema
await grafo.visit('pix:nao-concluido');
await grafo.visit('pix:saldo-insuficiente', 'descartado');
await grafo.visit('pix:limite-atingido');                  // abre as regras do Banco Central
await grafo.visit('pix:limite-atingido', 'descartado');
await grafo.visit('pix:modo-seguro', 'confirmado');
grafo.setMode('rede');                                     // mesmo estado, outro desenho
```

Na referência, essa sequência pode ser colada no console do navegador trocando `grafo` por `REAL` (pause o roteiro antes com `sc.phase = 'gap'`).

Olhe a tela, não só o código. Vários defeitos deste projeto só apareceram em captura de tela: barras sem preenchimento, rótulos sobrepostos, nós fora da área visível. Se você consegue tirar screenshots, tire um por estado e compare com `docs/img/`.

## Limites conhecidos da referência

- O servidor acha o tema de entrada por busca textual. Funciona para a demo e é fraco para frases vagas. No produto, o agente deve informar o nó, ou a busca deve ser semântica.
- As sessões ficam na memória do processo.
- A resposta vem inteira por turno. Se o agente real emitir passos ao longo do tempo, a troca natural é por SSE; `playTrace` já consome um passo por vez.
- A base tem um mês de dados.
- Em 1440 px de largura o texto dos nós fica perto de 11 px. É o limite inferior aceitável.

## Conteúdo do pacote

```
README.md                  este arquivo
hugin-graph.js             o módulo do card (o que se porta)
hugin-demo.html            a página de referência
DESIGN.md, PRODUCT.md      contexto visual e de produto
docs/
  GUIA-DE-PORTE.md         o guia completo
  grafo-real.md            API, MongoDB, regra e fontes
  img/                     o alvo de cada estado
server/
  server.mjs               rotas, sessão, o que vai para a tela
  rank.mjs, rank.test.mjs  a regra de priorização e os testes
  db.mjs                   MongoDB: conexão, seed, consultas
  seed/                    a base (cgov.json, pix.json, curadoria.json)
  scripts/build-seed.mjs   gera cgov.json a partir do CSV público
```
