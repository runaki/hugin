# Guia de porte — card "Grafo de memória" do Hugin

Este guia explica como adotar o card no frontend do produto: o que ele é, como é construído, como anima, como funcionam os dois desenhos (árvore e rede) e como ele se comporta em cada situação. Os números aqui foram lidos do código (`hugin-graph.js`, `hugin-demo.html`, `server/rank.mjs`), não estimados.

O contrato completo da API, o modelo no MongoDB e a origem dos dados estão em [grafo-real.md](grafo-real.md). Este guia cita só o que o card consome.

![Tela inteira](img/00-tela-inteira.png)

## Sumário

1. [O que é o card](#1-o-que-é-o-card)
2. [Rodar a referência](#2-rodar-a-referência)
3. [Quem decide o quê](#3-quem-decide-o-quê)
4. [Adoção passo a passo](#4-adoção-passo-a-passo)
5. [Como o card é construído](#5-como-o-card-é-construído)
6. [Os estados do card](#6-os-estados-do-card)
7. [Vocabulário visual](#7-vocabulário-visual)
8. [O que o card recebe](#8-o-que-o-card-recebe)
9. [O ciclo de uma chamada](#9-o-ciclo-de-uma-chamada)
10. [Animação](#10-animação)
11. [Desenho 1: árvore](#11-desenho-1-árvore)
12. [Desenho 2: rede](#12-desenho-2-rede)
13. [Antes do grafo: a lista de hipóteses](#13-antes-do-grafo-a-lista-de-hipóteses)
14. [A câmera](#14-a-câmera)
15. [Como se comporta, evento por evento](#15-como-se-comporta-evento-por-evento)
16. [Portar para o seu stack](#16-portar-para-o-seu-stack)
17. [Ligar no agente real](#17-ligar-no-agente-real)
18. [Checklist de aceite](#18-checklist-de-aceite)
19. [Armadilhas](#19-armadilhas)
20. [Onde mexer para mudar cada coisa](#20-onde-mexer-para-mudar-cada-coisa)

---

## 1. O que é o card

O card mostra, ao vivo, o que o agente está consultando na base de conhecimento durante um atendimento. Ele tem três trabalhos:

- **Mostrar o caminho do raciocínio**: qual tema a conversa está, que problema o cliente citou, que causas o agente verificou e qual confirmou.
- **Não poluir**: a base tem 143 nós e 1.094 relações; a tela mostra no máximo 12 nós. O resto fica atrás de um "+N ocultos".
- **Ser honesto sobre a origem**: cada nó diz de que fonte veio, e relação sem contagem real aparece tracejada.

O público é executivo. Por isso o card é parado e legível: nada se mexe sem motivo, não há brilho nem partículas, e o texto é grande.

## 2. Rodar a referência

```bash
cd server
npm install
npm start            # http://localhost:4777
```

Abra a aba "Atendimento ao vivo". Rodam dois atendimentos em sequência:

1. **Lucas** chega sem contexto: o card vai de "sem pista" a "hipóteses" e só então abre o grafo.
2. **Camila** fala da fatura do cartão e depois revela que o problema é o Pix: mudança de tema.

O seletor **Árvore | Rede**, no canto do card, troca o desenho na hora. Clique em qualquer nó para navegar a base por conta própria.

A primeira subida baixa o MongoDB (~590 MB, uma vez) e leva de 15 a 20 segundos. Para usar o seu Mongo: `MONGODB_URI=... npm start`.

## 3. Quem decide o quê

Esta divisão é a decisão de arquitetura mais importante. Mantenha-a.

```
  fala do cliente / passo do agente
                │
                ▼
┌──────────────────────────────┐        ┌───────────────────────────────┐
│  SERVIDOR  (server/)         │  view  │  CARD  (hugin-graph.js)       │
│  decide O QUE aparece        │ ─────► │  decide COMO aparece          │
│  · que tema é                │  trace │  · posição de cada nó         │
│  · quais 12 nós              │  shift │  · forma, cor, rótulo         │
│  · ordem em que acendem      │        │  · animação e câmera          │
│  · se mudou de tema          │        │  · árvore ou rede             │
└──────────────────────────────┘        └───────────────────────────────┘
```

O card nunca filtra, ordena por relevância ou esconde nós por conta própria. Ele desenha exatamente o que recebe. Isso mantém a regra de priorização num lugar só (`server/rank.mjs`, com testes) e permite trocar o desenho sem tocar na regra.

O card não conhece a base inteira. Ele só vê o subgrafo da vez.

## 4. Adoção passo a passo

Faça nesta ordem. Cada etapa tem um critério de pronto que dá para verificar na tela.

| # | Etapa | Pronto quando |
|---|---|---|
| 1 | Rode a referência e assista aos dois atendimentos nos dois desenhos | Você consegue explicar o que cada marca significa sem olhar a legenda |
| 2 | Suba o servidor no seu ambiente (ou aponte para ele) | `GET /api/health` responde `{ "ok": true }` |
| 3 | Monte o card vazio: contêiner com tamanho definido, `mountMemoryGraph(el)` | O canvas ocupa o contêiner e redimensiona com ele |
| 4 | Ligue uma chamada: `grafo.consult('não consigo pagar a fatura do cartão')` | Aparecem o tema, 5 vizinhos e um "+43 ocultos", e o tema e o problema citado acendem em sequência |
| 5 | Construa a moldura do card (seção 5): trilha de temas, contador, legenda, seletor | A trilha de temas e o contador mudam a cada chamada |
| 6 | Ligue o painel de detalhe no `onStep` | Cada nó que acende atualiza fonte, texto e nota |
| 7 | Trate os estados antes do grafo (seção 13) | `consult('')` mostra o mapa geral; uma fala vaga mostra hipóteses com nota |
| 8 | Teste a mudança de tema | A fala sobre Pix recolhe Cartão para o topo e abre o mundo Pix |
| 9 | Ligue no agente real (seção 17) | O card reage ao agente, não a um roteiro |
| 10 | Passe o checklist da seção 18 | Todos os itens marcados |

Se o seu stack permite carregar um módulo ES e um script, as etapas 3 e 4 são copiar `hugin-graph.js` e servir o `force-graph.min.js`. O trabalho de verdade está nas etapas 5 a 9.

## 5. Como o card é construído

O card são dois painéis empilhados na coluna direita: o **grafo** em cima e o **detalhe** embaixo.

```
┌─ painel do grafo ───────────────────────────────────────────┐
│ ◈ Grafo de memória  [base real]         9 de 143 nós · +58  │ ← cabeçalho
├─────────────────────────────────────────────────────────────┤
│ Cartão › Pix   mudança de tema              [Árvore|Rede]   │ ← trilha de temas + seletor (34 px)
│                                                             │
│                                                             │
│                    ÁREA DO CANVAS                           │ ← #graph-real
│                    (hugin-graph.js)                         │
│                                                             │
│                                                             │
│ ● Tema ● Problema ● Causa ● Regra — dado real ┄ curadoria   │ ← legenda (30 px)
└─────────────────────────────────────────────────────────────┘
┌─ painel de detalhe ("Recuperado") ──────────────────────────┐
│ ▤ CENTRAL DE AJUDA PICPAY · MOTIVO 4            ver fonte   │ ← fonte + link
│ Modo Seguro ativado — O Modo Seguro pode bloquear Pix…      │ ← texto (4 linhas, altura fixa)
│ prioridade ▓▓▓▓▓▓▓░░░░░░░░░░░░ 0,39                         │ ← nota
│ relevância 0,00 · frequência 0,70 · continuidade 1,00       │ ← parcelas da nota
│ ─────────────────────────────────────────────────────────── │
│ prioridade = 50% relevância + 35% frequência real + 15% …   │ ← a regra, sempre visível
└─────────────────────────────────────────────────────────────┘
```

### 5.1 Estrutura (HTML da referência)

```html
<div class="panel">
  <div class="p-head">
    <svg>…</svg><h3>Grafo de memória</h3>
    <span class="chip good" id="graph-live">base real</span>
    <span class="tail" id="graph-stat">9 de 143 nós · +58 ocultos</span>
  </div>
  <div class="graph-wrap">                      <!-- position: relative; flex: 1 -->
    <div id="graph-real"></div>                 <!-- o canvas: position:absolute; inset: 34px 0 30px -->
    <div class="graph-crumb" id="graph-crumb"></div>    <!-- trilha de temas, topo esquerdo -->
    <div class="graph-mode" id="graph-mode">…</div>     <!-- seletor Árvore | Rede, topo direito -->
    <div class="graph-legend" id="graph-legend"></div>  <!-- legenda, base -->
  </div>
</div>
<div class="panel retrieval real" id="retrieval">
  <div class="r-src"><svg>…</svg><span id="r-src"></span><a id="r-link">ver fonte</a></div>
  <div class="r-tx" id="r-tx"></div>
  <div class="r-conf"><span id="r-lbl">prioridade</span><div class="track"><div class="fill" id="r-fill"></div></div><span id="r-pct"></span></div>
  <div class="r-fx" id="r-fx"></div>
  <div class="r-rule" id="r-rule"></div>
</div>
```

### 5.2 Zonas e quem preenche cada uma

| Zona | Preenchida por | Conteúdo |
|---|---|---|
| Cabeçalho: contador | `onView` | `"{visible} de {total} nós · +{hidden} ocultos"`. Antes do grafo: `"sem pista"` ou `"4 hipóteses"` |
| Cabeçalho: selo | fixo | "base real" quando o grafo vem do servidor |
| Trilha de temas | `onView` | Temas anteriores riscados, `›`, tema atual em destaque. Na troca, o aviso "mudança de tema" em âmbar |
| Seletor | clique | Chama `grafo.setMode('arvore' \| 'rede')` e guarda a escolha em `localStorage` (`hugin-grafo`) |
| Canvas | `hugin-graph.js` | Nós, conectores, rótulos, pulso, anel |
| Legenda | uma vez, na montagem | As 4 cores de tipo e as 2 linhas (cheia = dado real, tracejada = curadoria) |
| Detalhe: fonte | `onStep` | Nome da fonte e, se houver, a referência (motivo do artigo, norma do BCB). Link `ver fonte` |
| Detalhe: texto | `onStep` | Rótulo oficial em negrito + o texto da fonte, ou a contagem de reclamações |
| Detalhe: nota | `onStep` | Barra e número de `p`. Para nós sem nota: "âncora", "ponte", "contexto" ou "trilha" |
| Detalhe: parcelas | `onStep` | `relevância · frequência · continuidade` |
| Detalhe: regra | uma vez | A fórmula e os limites, lidos de `GET /api/meta` |

### 5.3 Medidas que importam

- **A área do canvas precisa de largura e altura definidas.** Na referência é `position: absolute; inset: 34px 0 30px` dentro de um contêiner `position: relative; flex: 1; min-height: 0`. Os 34 px de cima são da trilha de temas e do seletor; os 30 px de baixo, da legenda. Sem essa reserva, os nós passam por baixo da legenda.
- **O texto do detalhe tem altura fixa** (80 px, 4 linhas com `line-clamp`). Se o painel de detalhe mudar de altura, a área do canvas muda junto e a câmera reenquadra: o grafo "pula" a cada nó.
- **Largura mínima confortável**: 440 px de canvas. Abaixo disso o zoom cai e o texto fica com menos de 11 px.
- O canvas escuta `ResizeObserver` e se ajusta sozinho.

### 5.4 Cores e tipografia

O card usa os tokens da página. Os que ele lê diretamente:

| Uso | Valor |
|---|---|
| Tema | `#2bbd66` |
| Problema | `#56b7ad` |
| Causa | `#d6a344` |
| Regra | `#9a8fdc` |
| Texto | `#eef2ef` |
| Texto apagado / "+N" | `#9aa89f` |
| Placa atrás do rótulo | `#111714` |
| Pulso | `#8fe6b0` |
| Conector | `rgba(150,175,160, .3)` normal, `.6` na trilha |

A **placa atrás do rótulo tem de ser a cor do fundo do painel**. É ela que esconde o conector onde ele passaria por cima do texto. Se o seu painel tem outro fundo, troque `PLATE` em `hugin-graph.js`.

Fontes da referência: Sora (títulos e números), Hanken Grotesk (interface e rótulos do grafo), JetBrains Mono (contadores e a linha da regra). O canvas herda a `font-family` do contêiner.

## 6. Os estados do card

O card tem quatro estados. Todos vêm do campo `view.state` e de `view.theme`.

| Estado | Condição | Canvas | Trilha de temas | Contador | Detalhe |
|---|---|---|---|---|---|
| Vazio | antes da 1ª chamada | nada | vazio | `0 de 143 nós` | "nenhuma consulta ainda" |
| **Sem pista** | `state: "frio"` | lista do mapa geral | "Sem pista ainda" | `sem pista` | "Nenhuma pista." + regra de entrada |
| **Hipóteses** | `state: "hipoteses"` | lista de hipóteses com nota | "Entendendo a demanda" | `4 hipóteses` | as hipóteses e entre quais o agente pergunta |
| **Grafo** | `state: "ancorado"` | árvore ou rede | tema atual (e anteriores riscados) | `9 de 143 nós · +58 ocultos` | o nó que acabou de acender |

| Sem pista | Hipóteses |
|---|---|
| ![Sem pista](img/01-sem-pista.png) | ![Hipóteses](img/02-hipoteses.png) |

| Grafo (árvore) | Grafo (rede) |
|---|---|
| ![Árvore](img/03-arvore-tema-aberto.png) | ![Rede](img/04-rede-tema-aberto.png) |

## 7. Vocabulário visual

Toda marca codifica estado. Não há enfeite. Preserve este código ao portar: é o que permite ler o card sem legenda depois de dois minutos.

| Marca | Significado | Vem de |
|---|---|---|
| Cor do círculo | Tipo do nó: tema, problema, causa, regra | `node.kind` |
| Círculo **cheio** | A conversa está apoiada nele: âncora, foco, trilha ou ponte | `role` em `ancora`, `foco`, `trilha`, `ponte` |
| Círculo **vazado** (preenchimento a 20%) | Vizinho: entrou pela nota de prioridade, ainda não foi tocado | `role: "vizinho"` |
| Rótulo em **negrito** (600) | Mesmo critério do círculo cheio | idem |
| Nó a **50% de opacidade** | Tema anterior, ou hipótese descartada | `role: "contexto"` ou `status: "descartado"` |
| **Risco diagonal** sobre o círculo | Hipótese verificada e descartada | `status: "descartado"` |
| **Anel extra** permanente | Causa confirmada, ou caso encaminhado | `status: "confirmado"` ou `"resolvido"` |
| **Anel que se abre** e some | O nó acabou de acender | passo do `trace` |
| **Ponto que viaja** pelo conector | De onde o agente veio para chegar no nó | `trace[i].via` |
| Conector **verde e mais grosso** por 1,7 s | Acabou de ser percorrido | idem |
| Conector **tracejado** | Relação de curadoria, sem contagem real | `link.src` em `curadoria`, `salto`, `more` |
| Conector mais **claro** | Liga dois nós da trilha | papéis das duas pontas |
| Pílula tracejada **"+N ocultos"** | O que aquele nó ainda esconde. Clicável | `kind: "more"`, `count` |
| Círculo **tracejado cinza** (lista) | Item do mapa geral: não é hipótese | `role: "mapa"` |
| Barra + número (lista) | Nota da hipótese | `p` |

Tamanhos: raio 8 para tema, 6 para problema e causa, 5 para regra. No desenho em rede, todos ganham 2.

## 8. O que o card recebe

Cada chamada devolve `{ sessionId, view, trace, shift }`.

```ts
type View = {
  state: 'frio' | 'hipoteses' | 'ancorado';
  theme: string | null;          // id do tema atual
  past: string[];                // temas anteriores, do mais recente para o mais antigo
  nodes: Node[];                 // TUDO o que deve estar na tela
  links: Link[];                 // só as ligações estruturais (quem revelou quem + a ponte)
  mesh: Link[];                  // demais relações reais entre nós visíveis (só o desenho em rede usa)
  stats: { visible: number; hidden: number; total: number; edges: number };
  ask?: { open: boolean; options: string[]; asked: number; handoff: boolean };   // só antes do grafo
  forced?: true;                 // entrou no grafo porque acabaram as perguntas
};

type Node = {
  id: string; kind: 'tema' | 'problema' | 'causa' | 'regra' | 'more';
  short: string;                 // nome curto: é o rótulo no canvas
  label?: string;                // nome oficial: tooltip e painel de detalhe
  role: 'ancora' | 'foco' | 'trilha' | 'ponte' | 'contexto' | 'vizinho' | 'hipotese' | 'mapa';
  status?: 'consultado' | 'descartado' | 'confirmado' | 'resolvido';
  parent?: string;               // quem revelou este nó: define a posição na árvore
  p?: number;                    // nota de prioridade, 0..1
  factors?: { rel: number; freq: number; ctx: number };
  w?: number; wCompany?: number; // reclamações no setor / do PicPay
  src: string; ref?: { title: string; url: string }; detail?: string;
  count?: number;                // só em kind 'more'
  why?: 'fala' | 'perfil' | 'base'; hint?: string;   // só em hipóteses
};

type Link = { source: string; target: string; rel: string; w?: number; p?: number; src: string };

type Step = { node: string; via: string | null;
  why: 'tema' | 'cliente' | 'ponte' | 'novo-tema' | 'consultado' | 'descartado' | 'confirmado' | 'resolvido' };

type Shift = { from: string; to: string; bridge: string[]; kind: 'ponte' | 'salto' } | null;
```

Três campos sustentam o desenho:

- **`parent`** define a árvore. Sem ele, o nó é pendurado no tema.
- **`role`** define se o nó é cheio ou vazado e onde ele fica (contexto e ponte vão para cima do tema).
- **`trace`** define a ordem da animação. O card não deduz essa ordem de nada.

## 9. O ciclo de uma chamada

```
consult() / visit()
   │  entra na fila (uma chamada por vez)
   ▼
fetch POST ──► resposta { view, trace, shift }
   │
   ├─ apply(view)
   │    1. reaproveita o objeto dos nós que já estavam na tela (mantém x, y)
   │    2. cria os novos com born = agora
   │    3. layout(): calcula tx, ty de cada nó e os limites do desenho
   │    4. nó novo recebe x, y de quem o revelou (vai deslizar de lá)
   │    5. entrega nós e ligações ao force-graph
   │    6. frame(): ajusta a câmera, se precisar
   │
   ├─ onView(view, shift)        ← moldura: contador, trilha de temas
   │
   └─ playTrace(trace)           ← para cada passo, em sequência:
        · pulso viaja de via até node        (522 ms)
        · anel se abre em node, onStep(...)  ← painel de detalhe
        · espera                             (570 ms)
   ▼
a promise resolve
```

Duas consequências práticas:

- **`await grafo.visit(...)` só volta quando a trilha terminou de acender.** Dá para encadear passos sem cronômetro.
- **As chamadas são enfileiradas.** Um clique do usuário durante um passo do agente espera a vez. Sem a fila, duas respostas chegariam fora de ordem e o card mostraria um estado que não existe.

## 10. Animação

### 10.1 Princípio

Só anima o que acabou de acontecer. Depois, tudo fica parado. Uma versão anterior usava layout de física, em que os nós se empurram até assentar; foi rejeitada porque "fica se mexendo, ruim de acompanhar". Não reintroduza movimento contínuo.

### 10.2 Inventário

São seis animações. Não há outras.

| # | Animação | Gatilho | Duração | Curva | Onde no código |
|---|---|---|---|---|---|
| 1 | **Nascer**: nó e conector surgem | Nó novo na `view` | 350 ms | linear, opacidade 0 → 1 | `born` em `drawNode`, `drawLink` |
| 2 | **Deslizar**: nó vai de quem o revelou até o lugar | Nó novo, ou posição mudou | ~400 ms | exponencial: 20% do que falta por quadro | `glide()` |
| 3 | **Pulso**: ponto viaja pelo conector | Passo do `trace` com `via` | 522 ms (`stepMs × 0,55`) | suave nas pontas: `t²(3 − 2t)` | `drawPulses()` |
| 4 | **Conector aceso**: verde, 2,2 px | Junto com o pulso | 1.700 ms, corta seco | — | `isLit()` |
| 5 | **Anel**: abre a partir do nó e some | Fim do pulso | 1.100 ms | linear: raio `r+2` → `r+13`, opacidade 0,8 → 0 | `ringAt` em `drawNode` |
| 6 | **Câmera**: zoom e centro | Árvore deixou de caber, sobrou espaço, ou tema novo | 450 ms | a do force-graph | `frame()` |

### 10.3 Tempo de um passo

Com `stepMs = 950` (padrão):

```
0 ms       pulso parte de `via`, conector acende
522 ms     pulso chega; anel começa a abrir; onStep() atualiza o painel de detalhe
1.092 ms   próximo passo começa
1.622 ms   anel termina
1.700 ms   conector volta à cor normal
```

Um passo sem `via` (o primeiro tema da conversa) pula o pulso: anel e `onStep` na hora, e 570 ms de espera.

Na demo, o roteiro ainda segura cada passo do agente por 2.400 ms para dar tempo de ler o painel. Isso é do roteiro (`stepDur` em `hugin-demo.html`), não do card.

### 10.4 Como o desenho contínuo funciona

O canvas redesenha a cada quadro (`autoPauseRedraw(false)`), mesmo com tudo parado. É isso que permite o anel e o pulso, que dependem do relógio e não de mudança de dados. Cada animação é uma função do tempo:

```js
const t = (agora - ringAt.get(node.id)) / 1100;   // 0..1
if (t < 1) desenhaAnel(raio + 2 + t * 11, opacidade = (1 - t) * 0.8);
```

Não há biblioteca de animação nem estado de "animando". Guarda-se só o instante em que a coisa começou (`born`, `ringAt`, `litAt`, `pulses[].t0`).

### 10.5 Movimento reduzido

`opts.reduceMotion` é uma função consultada a cada uso. Quando devolve `true`:

- sem pulso e sem anel;
- o nó aparece direto no lugar (o deslize vira um salto: fator 1 em vez de 0,2);
- a câmera troca sem transição;
- cada passo espera 250 ms em vez de 570.

O estado final é idêntico. Ligue isso a `prefers-reduced-motion` e a um controle da interface.

### 10.6 O que nunca anima

- A posição de um nó que já está no lugar. Irmãos não trocam de posição quando chega um nó novo.
- Cor e preenchimento. Um nó que vira "descartado" muda no quadro seguinte, sem transição.
- Texto.

## 11. Desenho 1: árvore

É o desenho padrão. Lê como um organograma deitado: o tema à esquerda, o que ele revela à direita.

![Árvore com regras abertas](img/06-arvore-regras-abertas.png)

### 11.1 Regras de posição

- **Coluna = profundidade.** O tema fica na coluna 0. Quem ele revelou, na coluna 1. Quem um problema revelou, na coluna 2.
- **Linha = ordem de chegada.** O primeiro filho fica na mesma linha do pai. Os seguintes descem uma linha cada.
- **Irmãos na ordem em que apareceram**, nunca por nota. O "+N ocultos" é sempre o último.
- **Contexto e ponte ficam acima do tema**, empilhados na coluna 0. É o caminho por onde a conversa chegou: tema anterior no topo, depois a ponte, depois o tema atual.

```
coluna 0          coluna 1                 coluna 2               coluna 3
(146 px cada)

○ Cartão          ← contexto (tema anterior), 50% de opacidade
│
● Fatura: dif…    ← ponte
┊
● Pix ──────────┬─● Pix não concluído ──┬─○ Cadastro incompleto
                ┊                       ├─● Limite diário/… ───┬─○ Aumento: 24–48h
                ┊                       │                      ├─○ Noturno: R$ 1.000
                ┊                       │                      └┄ (+1 ocultos)
                ┊                       ├─⊘ Saldo insuficiente
                ┊                       └┄ (+5 ocultos)
                └┄○ Pagar/transferir…
```

### 11.2 Algoritmo

```
layout(view, nós):
  esquerda ← nós com role 'contexto' ou 'ponte'   (contexto primeiro, depois por ordem de chegada)
  para cada outro nó, exceto o tema:
      pai ← nó.parent, se estiver na tela e não for da esquerda; senão, o tema
  filhos de cada pai ← ordenados por ordem de chegada, com 'more' por último

  linha ← 0
  posicionar(nó, profundidade):
      nó.tx ← profundidade × COL
      nó.ty ← linha × ROW
      se não tem filhos: linha ← linha + 1
      senão: posicionar(cada filho, profundidade + 1)

  posicionar(tema, 0)
  esquerda[i].tx ← 0;  esquerda[i].ty ← (i − quantos) × ROW × 1,25
```

O primeiro filho herda a linha do pai porque `linha` só avança numa folha. Um pai com três filhos ocupa três linhas, e não quatro.

### 11.3 Constantes

| Constante | Valor | O que é |
|---|---|---|
| `COL` | 146 | Distância entre colunas |
| `ROW` | 36 | Distância entre linhas |
| `FONT` | 12,5 | Tamanho do rótulo |
| `LABEL_W` | 122 | Largura reservada para o rótulo da última coluna |
| `PAD` | 22 | Margem entre o desenho e a borda do canvas |

Estão em unidades do grafo. Com zoom 1, são pixels.

### 11.4 Rótulo

Fica à direita do nó, alinhado à esquerda, centrado na vertical. Quebra em até 2 linhas quando passa de 18 caracteres, no espaço mais perto do meio. Atrás dele há uma placa da cor do painel, do tamanho do texto mais o nó.

### 11.5 Conector em cotovelo

Três segmentos: sai do pai na horizontal, desce num tronco 18 px antes do filho, entra no filho.

```
pai ●────────────┐
                 │   ← tronco em filho.x − 18
                 └─● filho
```

O trecho horizontal passa por trás do rótulo do pai; a placa o esconde, e o conector parece sair do fim do texto. Entre nós da mesma coluna (contexto, ponte, tema) o conector é uma reta vertical. O pulso segue esse mesmo caminho, segmento a segmento (`route()`).

Espessura: 1,2 px; 2,2 px enquanto aceso.

### 11.6 Como se comporta

- **Abrir um tema**: o tema na coluna 0 e 5 vizinhos na coluna 1, mais o "+N".
- **O agente visita um problema**: o nó vira cheio e 3 vizinhos surgem na coluna 2, saindo dele. Os irmãos abaixo descem as linhas necessárias, uma vez.
- **Descartar um nó**: fica apagado e riscado no mesmo lugar. Os filhos que ele tinha aberto somem e os irmãos de baixo sobem.
- **Mudança de tema**: o tema antigo vai para o topo da coluna 0, apagado; a ponte fica entre os dois; o tema novo assume a coluna 0 e abre os próprios vizinhos. A câmera reenquadra do zero.

![Mudança de tema](img/05-arvore-mudanca-de-tema.png)

A árvore mostra bem o **caminho**: lê-se "Cartão → Fatura → Pix → Pix não concluído → Modo Seguro" de cima para baixo e da esquerda para a direita.

![Causa confirmada](img/07-arvore-causa-confirmada.png)

## 12. Desenho 2: rede

É a proposta alternativa. Lê como um diagrama de rede neural: camadas em colunas, neurônios empilhados, sinapses com peso.

![Rede](img/04-rede-tema-aberto.png)

### 12.1 Regras de posição

- **Coluna = tipo do nó**, não profundidade. Temas na camada 0, problemas na 1, causas na 2, regras na 3. O nome da camada aparece no topo.
- **Linha = ordem de chegada dentro da camada**, a partir do topo. Quem entra vai para o fim da camada.
- Na camada de temas, o tema atual é sempre o primeiro; temas de contexto vêm em seguida; depois as portas para outros temas.
- O "+N ocultos" fica no fim da camada do que ele esconde: uma à direita do nó dono, ou a camada 0 quando o dono é um problema que abriu portas para temas.

A diferença para a árvore: aqui um tema revelado por um problema (uma "porta") volta para a camada 0, ao lado do tema atual. A ligação cruza de volta para a esquerda.

### 12.2 Algoritmo

```
layoutRede(view, nós):
  para cada nó: camada ← { tema: 0, problema: 1, causa: 2, regra: 3 }[nó.kind]
                (para 'more': a regra do item anterior)
  em cada camada, ordenar por: tema atual, contexto, demais, '+N'; empate pela ordem de chegada
  nó.tx ← camada × NCOL
  nó.ty ← posição na camada × NROW
```

### 12.3 Constantes

| Constante | Valor | O que é |
|---|---|---|
| `NCOL` | 158 | Distância entre camadas |
| `NROW` | 62 | Distância entre neurônios (maior que na árvore: o rótulo fica embaixo) |
| `HEAD` | 28 | Altura reservada para o nome das camadas |

### 12.4 Rótulo

- **Camada 0**: à esquerda do neurônio, alinhado à direita.
- **Demais camadas**: embaixo do neurônio, centrado.

Assim o espaço entre as camadas fica livre para as sinapses. Os neurônios têm raio 2 px maior que os nós da árvore.

### 12.5 Sinapses

São retas, de neurônio a neurônio.

- **Espessura = frequência real.** `1 + 3,5 × √(w / maior w da tela)`, o que dá de 1 a 4,5 px. A raiz quadrada evita que a relação mais forte esmague as outras. Relação sem contagem (curadoria) fica em 1,2 px.
- **Tracejada** quando é curadoria, como na árvore.
- **Malha**: as relações em `view.mesh` (reais, entre nós visíveis, que não fazem parte da estrutura) são desenhadas a 0,8 px e 13% de opacidade, atrás de tudo. É o que dá a aparência de rede. Nenhuma linha é inventada.

### 12.6 Como se comporta

- **Abrir um tema**: o tema na camada 0, os problemas na camada 1, sinapses com espessuras diferentes.
- **O agente visita um problema que abre portas**: os temas vizinhos aparecem na camada 0, abaixo do tema atual, e a malha cresce.
- **Causas e regras**: abrem as camadas 2 e 3 quando aparecem. O zoom diminui se a nova camada não couber.
- **Mudança de tema**: o tema novo sobe para o topo da camada 0 e o antigo fica logo abaixo, apagado. As camadas à direita são trocadas.

![Rede com causa confirmada](img/08-rede-causa-confirmada.png)

### 12.7 Árvore ou rede

| | Árvore | Rede |
|---|---|---|
| Mostra melhor | O **caminho** da conversa | A **estrutura** e os **pesos** |
| Mudança de tema | Explícita: o caminho fica empilhado acima | Menos óbvia: os dois temas ficam lado a lado na mesma camada |
| Espaço | Compacta; cabe bem em 440 px | Pede mais largura e altura |
| Frequência real | Só no painel de detalhe | Visível na espessura da sinapse |
| Situação | Padrão, aprovado | Proposta alternativa |

Os dois usam os mesmos dados, a mesma animação e o mesmo vocabulário. `grafo.setMode()` troca um pelo outro sem refazer a conversa: os nós deslizam de uma posição para a outra.

## 13. Antes do grafo: a lista de hipóteses

Enquanto `view.theme` é `null`, não há grafo. O canvas mostra uma lista, igual nos dois desenhos.

- Uma linha por candidato, 46 px de altura, na ordem que o servidor mandou (maior nota primeiro).
- Cada linha: círculo de raio 7, nome em 12,5 px, e embaixo a origem da pista em 10 px.
- **Hipótese** (`role: "hipotese"`): círculo na cor do tipo com 20% de preenchimento, nome em negrito, e à direita uma barra de 64 px com a nota.
- **Mapa geral** (`role: "mapa"`): círculo cinza tracejado, nome apagado, sem barra. É o que a base tem de mais frequente, não uma suspeita sobre este cliente.
- Título no topo: `SEM PISTA · MAPA GERAL DA BASE` ou `HIPÓTESES · NENHUMA VENCE AINDA`.

A linha de origem diz de onde veio a pista:

| `why` | Texto |
|---|---|
| `fala` | "pela fala do cliente" |
| `perfil` | "perfil: " + `hint` (por exemplo "perfil: Pix recusado há 5 min") |
| `base` | "59.953 reclamações na base" |

A linha inteira é clicável. Clicar entra no grafo por aquele tema.

Quando a demanda é entendida, os candidatos que continuam na tela deslizam para a posição nova e os outros somem. O tema escolhido vira a âncora sem piscar, porque é o mesmo objeto.

`view.ask` orienta o agente: `open: true` pede pergunta aberta; `options` traz os nomes para uma pergunta dirigida; `handoff: true` indica que passou do limite de perguntas sem hipótese nenhuma.

## 14. A câmera

A câmera é o que mais afeta a sensação de "parado". Três regras, em `frame()`:

1. **O canto superior esquerdo do desenho é fixo.** A câmera é posicionada para que o canto dos limites fique a `PAD` da borda. Um nó novo, à direita ou embaixo, não desloca os que já estavam.
2. **O zoom só muda em três casos**: o desenho deixou de caber; passou a sobrar mais de 15% de espaço; ou o tema mudou. Entrar um nó que cabe não mexe no zoom.
3. **Teto de 1,5.** Com poucos nós, o desenho não estoura.

```
zoomQueCabe = min( (largura − 2·PAD) / larguraDoDesenho,
                   (altura  − 2·PAD) / alturaDoDesenho,
                   1,5 )
zoom = (tema mudou, ou não cabe, ou sobra > 15%) ? zoomQueCabe : zoom atual
```

A transição leva 450 ms. Redimensionar o contêiner reenquadra do zero.

O usuário pode arrastar e dar zoom com o mouse. A próxima chamada que exigir reenquadrar desfaz isso. Arrastar nó está desligado.

## 15. Como se comporta, evento por evento

| Evento | Chamada | O que o servidor faz | O que se vê no card |
|---|---|---|---|
| Cliente chega sem dizer nada | `consult('')` | Estado `frio`, 5 temas mais frequentes | Lista "sem pista", contador "sem pista" |
| Cliente chega e há pista no perfil | `consult('', hints)` | Soma 0,30 ao tema da pista | Lista de hipóteses com "perfil: …" |
| Fala vaga | `consult('não consigo pagar')` | Evidência acumula; sem vencedor claro | Hipóteses com nota; as que continuam mantêm o lugar |
| Fala que resolve | `consult('é a fatura do cartão')` | Vencedor com margem: entra no tema | A lista vira grafo; tema e problema citado acendem em sequência |
| Fala clara logo de início | `consult('não consigo pagar a fatura do cartão')` | Entra direto | Grafo, sem passar pela lista |
| Agente consulta um nó | `visit(id)` | Marca como trilha, abre 3 vizinhos | Pulso até o nó, nó fica cheio, filhos surgem |
| Agente descarta uma hipótese | `visit(id, 'descartado')` | Fecha o nó | Nó apagado e riscado; filhos somem |
| Agente confirma a causa | `visit(id, 'confirmado')` | Fecha o nó | Anel permanente em volta |
| Agente encerra | `visit(id, 'resolvido')` | Fecha o nó | Anel permanente |
| Cliente muda de assunto | `consult('estou pagando por Pix…')` | Tema novo vence por 25%: acha a ponte | Aviso "mudança de tema"; o caminho acende do nó conhecido até o tema novo |
| Navegação por uma porta | `visit('tema:…')` | Mesma troca de tema | Idem |
| Clique em "+N ocultos" | `visit('more:<id>')` | Mostra a próxima leva (5 ou 3) | Novos irmãos no fim; o "+N" diminui |
| Passou do teto de 12 nós | qualquer | Derruba o vizinho de menor nota | Um vizinho some e o "+N" do pai dele cresce |
| Fala sem relação com a base | `consult('ok, obrigada')` | Nada muda | Nada muda |
| Volta a um tema anterior | `consult(...)` | Restaura a trilha daquele tema | O que tinha sido consultado lá reaparece cheio |
| 2 perguntas sem vencedor | `consult(...)` | Entra com a melhor, `forced: true` | Grafo; vale avisar que foi a melhor hipótese |
| Sem hipótese após 2 perguntas | `consult(...)` | `ask.handoff: true` | Lista "sem pista"; o detalhe pede encaminhar a um humano |
| Nova conversa | `reset()` | Sessão nova | Card vazio |

## 16. Portar para o seu stack

### 16.1 Caminho A: manter o canvas

É o caminho recomendado. `hugin-graph.js` não depende de framework: recebe um elemento e devolve um objeto.

```js
import { mountMemoryGraph, KIND_COLOR, KIND_LABEL } from './hugin-graph.js';
import ForceGraph from 'force-graph';

const grafo = await mountMemoryGraph(el, {
  api: 'https://seu-backend',          // '' = mesma origem
  ForceGraph,                          // dispensável se houver window.ForceGraph
  mode: 'arvore',                      // ou 'rede'
  stepMs: 950,
  reduceMotion: () => matchMedia('(prefers-reduced-motion: reduce)').matches,
  onStep({ node, via, why, data, link }) { /* painel de detalhe */ },
  onView(view, shift) { /* contador, trilha de temas */ },
});
```

| Método | O que faz |
|---|---|
| `consult(text = '', hints?)` | O cliente falou. Texto vazio = chegou sem dizer nada. `hints: [{ node, label }]` são pistas do perfil |
| `visit(nodeId, status?)` | O agente ou um clique foi até um nó |
| `reset()` | Nova conversa |
| `setMode('arvore' \| 'rede')` | Troca o desenho |
| `view`, `mode`, `meta` | Estado atual, desenho atual e o que veio de `/api/meta` |
| `destroy()` | Solta o `ResizeObserver` e o canvas |

Em React:

```jsx
function GrafoDeMemoria({ onStep, onView, mode }) {
  const el = useRef(null), grafo = useRef(null);
  useEffect(() => {
    let vivo = true;
    mountMemoryGraph(el.current, { onStep, onView, mode }).then(g => { vivo ? (grafo.current = g) : g.destroy(); });
    return () => { vivo = false; grafo.current?.destroy(); };
  }, []);
  useEffect(() => { grafo.current?.setMode(mode); }, [mode]);
  return <div ref={el} style={{ position: 'absolute', inset: '34px 0 30px' }} />;
}
```

O estado do grafo vive no módulo. O componente guarda só o que chega por `onStep` e `onView`. Não recrie o grafo a cada render: a posição dos nós depende de reaproveitar os objetos.

### 16.2 Caminho B: reescrever em SVG ou DOM

Faz sentido se você precisa de acessibilidade por nó, de estilos em CSS ou não quer o `force-graph`. O `force-graph` aqui só fornece canvas, zoom, arraste e detecção de clique: a física está desligada (`cooldownTicks(0)`).

O que copiar literalmente, porque são funções puras de dados para posição:

- `layout()` e `layoutRede()`: devolvem `tx`, `ty` e os limites;
- `route()`: os pontos do conector;
- `wrap()`: a quebra do rótulo;
- a lógica de `frame()`: zoom e centro.

O que reescrever: `drawNode`, `drawLink`, `drawCandidate`, `drawBackdrop` e `drawPulses` viram elementos; `glide()` vira transição de `transform`; anel e pulso viram animações CSS ou `<animateMotion>` sobre o caminho de `route()`.

### 16.3 O que não pode se perder em nenhum dos caminhos

1. **Identidade do nó entre respostas.** Um nó que continua na tela é o mesmo objeto e mantém a posição. Em React, a chave é o `id`.
2. **Ordem de chegada** (`seen`): irmãos ordenados pelo momento em que apareceram pela primeira vez, não pela nota.
3. **Nascer de quem revelou**: o nó novo parte da posição do `parent`.
4. **Fila de chamadas**: uma por vez.
5. **A promise resolve no fim da trilha.**
6. **Câmera com canto fixo e zoom com histerese.**
7. **Placa atrás do rótulo** na cor do painel.
8. **Tracejado = sem contagem real.**

## 17. Ligar no agente real

Na demo, quem chama o card é um roteiro (`SCEN_REAL` em `hugin-demo.html`). No produto:

| Na demo | No produto |
|---|---|
| Passo `ask` do roteiro chama `consult(texto)` | Cada mensagem do cliente chama `consult(texto)` |
| Passo `open` chama `consult('')` | O atendimento começa com `consult('', pistasDoPerfil)` |
| Passo `go` chama `visit(nó, status)` | O agente chama `visit` quando consulta, descarta ou confirma um nó |
| Resultado da ferramenta vem do roteiro | Vem da ferramenta de verdade |
| O servidor acha o tema por busca textual | O agente informa o nó, ou a busca vira semântica |

Dois pontos de atenção:

- **Latência.** Hoje a resposta vem inteira e o card anima depois. Se o agente emitir passos ao longo de segundos, troque por SSE: `playTrace` já consome um passo por vez, então basta alimentá-lo conforme os passos chegam.
- **Texto das perguntas.** O servidor diz se a pergunta é aberta ou entre quais opções (`view.ask`). Quem escreve a frase é o agente.

## 18. Checklist de aceite

Card:

- [ ] O canvas ocupa a área reservada e redimensiona com a janela.
- [ ] Trilha de temas, seletor e legenda não são cobertos por nós.
- [ ] O painel de detalhe não muda de altura quando o texto muda.
- [ ] Em 1440 px de largura, o rótulo dos nós tem pelo menos 11 px.

Comportamento:

- [ ] `consult('')` mostra o mapa geral, com círculos tracejados e sem barra de nota.
- [ ] Uma fala vaga mostra hipóteses com barra e número.
- [ ] Clicar numa hipótese entra no grafo.
- [ ] Um tema aberto mostra 5 vizinhos e um "+N ocultos".
- [ ] `visit` num problema abre 3 vizinhos saindo dele.
- [ ] Nó descartado fica apagado e riscado; confirmado ganha anel permanente.
- [ ] Clicar no "+N" revela mais vizinhos e o número diminui.
- [ ] A tela nunca passa de 12 nós, fora os "+N".
- [ ] Na mudança de tema, o tema antigo fica apagado no topo e a ponte entre os dois.
- [ ] Relação de curadoria aparece tracejada nos dois desenhos.

Animação:

- [ ] Um nó que já estava na tela não muda de lugar quando entra um irmão.
- [ ] Nó novo nasce de quem o revelou e para.
- [ ] O pulso segue o conector, cotovelo incluído.
- [ ] Depois de 2 segundos sem chamada, nada na tela se move.
- [ ] O zoom não muda quando entra um nó que cabe.
- [ ] Com movimento reduzido, não há pulso nem anel e o estado final é o mesmo.
- [ ] Trocar de Árvore para Rede não refaz a conversa.

Honestidade:

- [ ] Cada nó mostra a fonte, e o link "ver fonte" abre.
- [ ] O contador mostra quantos nós da base estão fora da tela.

## 19. Armadilhas

- **Layout de física.** Já foi tentado e rejeitado. Se for usar `force-graph` de outra forma, mantenha `cooldownTicks(0)`.
- **`zoomToFit` a cada resposta.** Recentra o desenho inteiro a cada nó. Use a lógica de `frame()`.
- **Recriar os nós a cada resposta.** Perde posição e todo nó "nasce" de novo. Reaproveite o objeto por `id` e limpe os campos que podem ter saído (`STALE`).
- **Ordenar irmãos pela nota.** A nota muda a cada fala; os nós trocariam de lugar o tempo todo.
- **Contêiner sem altura.** O `force-graph` assume o tamanho da janela, e o desenho fica fora da área visível.
- **Elemento escondido com `hidden` e CSS que define `display`.** A regra do autor vence a do navegador. A referência declara `[hidden]{display:none!important}`.
- **Placa do rótulo em cor diferente do painel.** Aparecem retângulos atrás dos textos.
- **Esquecer `mesh` na rede.** Sem a malha, a rede fica igual a uma árvore torta.
- **Duas chamadas ao mesmo tempo.** Sem a fila, a resposta mais lenta sobrescreve a mais nova.
- **Painel de detalhe com altura variável.** Muda a área do canvas e dispara reenquadramento.
- **Abrir `hugin-demo.html` direto do disco.** Sem servidor não há API, e a página cai na simulação antiga, que tem outro grafo. Para ver o card real, use `http://localhost:4777`.

## 20. Onde mexer para mudar cada coisa

| Quero mudar | Arquivo | Onde |
|---|---|---|
| Quantos vizinhos aparecem, o teto de nós | `server/rank.mjs` | `RULE.K_ANCHOR`, `K_VISIT`, `MAX_VISIBLE` |
| Os pesos da nota de prioridade | `server/rank.mjs` | `RULE.W_REL`, `W_FREQ`, `W_CTX` |
| Quando a conversa troca de tema | `server/rank.mjs` | `RULE.SHIFT_MARGIN`, `MIN_ENTRY` |
| Quando entra no grafo, quantas perguntas | `server/rank.mjs` | `RULE.AMBIG_FLOOR`, `MAX_ASKS`, `HINT_VOTE`, `EVID_DECAY` |
| Cores dos tipos de nó | `hugin-graph.js` | `KIND_COLOR` |
| Espaçamento da árvore | `hugin-graph.js` | `COL`, `ROW` |
| Espaçamento da rede | `hugin-graph.js` | `NCOL`, `NROW` |
| Tamanho do texto dos nós | `hugin-graph.js` | `FONT` |
| Velocidade da trilha | opção `stepMs` | padrão 950 |
| Duração do anel, do conector aceso, do nascer | `hugin-graph.js` | `1100` em `drawNode`, `1700` em `isLit`, `350` em `drawNode` e `drawLink` |
| Quanto o zoom tolera antes de mudar | `hugin-graph.js` | `1.15` e `1.5` em `frame()` |
| Espessura das sinapses | `hugin-graph.js` | `1 + 3.5 * Math.sqrt(...)` em `drawLink` |
| Textos do painel de detalhe | `hugin-demo.html` | `onRealStep`, `onRealView` |
| O roteiro da demo | `hugin-demo.html` | `SCEN_REAL` |
| Nome curto e sinônimos de busca dos nós | `server/seed/curadoria.json` | `short`, `keywords` |
| A base de dados | `server/scripts/build-seed.mjs` | ver [grafo-real.md](grafo-real.md) |

Depois de mexer em `rank.mjs`, rode `npm test` na pasta `server`.
