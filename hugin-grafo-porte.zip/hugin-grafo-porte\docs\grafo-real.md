# Grafo de memória do Hugin — implementação de referência

Este é o grafo do painel "Grafo de memória" funcionando de verdade: um MongoDB com uma base pública real, um servidor que decide **o que** aparece na tela e um módulo de frontend que decide **como** aparece. Serve para você portar para o frontend do produto.

Este arquivo é a referência do **servidor**: API, MongoDB, regra de priorização e dados. Para portar o card (construção, animação, os dois desenhos, comportamento), o documento é o [GUIA-DE-PORTE.md](GUIA-DE-PORTE.md).

## Rodar

```bash
cd server
npm install
npm start          # http://localhost:4777
```

Sem configurar nada, o servidor sobe um `mongod` real e efêmero (pacote `mongodb-memory-server`, MongoDB 7.0) e carrega o seed. A primeira subida baixa o binário (~590 MB, uma vez) e o `mongod` leva de 15 a 20 segundos para ficar pronto.

Para usar o seu MongoDB ou o Atlas:

```bash
MONGODB_URI="mongodb+srv://..." MONGODB_DB=hugin npm start
```

Nesse caso o seed só é carregado se a coleção `nodes` estiver vazia. Para recarregar por cima, rode com `SEED=force`.

Testes da regra de priorização (não precisam de Mongo): `npm test`.

## O que é real e o que é roteiro

| Parte | Estado |
|---|---|
| Base de conhecimento (143 nós, 1.094 relações) | Real: dados públicos, com fonte em cada nó |
| MongoDB, busca textual, `$graphLookup` | Real |
| Regra de priorização e mudança de tema | Real: calculada no servidor a cada chamada |
| Grafo, painel "Recuperado", "Trilha do caso" | Real: mostram o que a API devolveu |
| Falas do cliente e do agente | Roteiro (`SCEN_REAL` em `hugin-demo.html`) |
| Resultado das ferramentas (saldo, limites, Modo Seguro da cliente) | Roteiro: dados sintéticos de uma cliente fictícia |
| Visão executiva (KPIs, volume, temas, eventos) | Simulação |

Quem decide qual nó visitar hoje é o roteiro. No produto, quem decide é o agente: ele chama `visit` quando consulta um nó.

Se a página for aberta direto do disco (`file://`), não há API: ela cai sozinha na simulação antiga, com o grafo desenhado à mão.

## Arquivos

| Arquivo | Papel |
|---|---|
| `hugin-graph.js` | **O módulo para portar.** Cliente da API, desenho com force-graph e animação da trilha. Sem framework. |
| `hugin-demo.html` | O layout. A integração está no bloco `grafo real (MongoDB)`: `initReal`, `onRealStep`, `onRealView`. |
| `server/rank.mjs` | **A regra de priorização.** Funções puras e as constantes `RULE`. |
| `server/rank.test.mjs` | Os testes da regra. |
| `server/server.mjs` | Rotas, sessão, entrada em tema, montagem do que vai para a tela. |
| `server/db.mjs` | Conexão, seed, índices e as cinco consultas ao Mongo. |
| `server/seed/cgov.json` | Grafo gerado do dado público (não editar à mão). |
| `server/seed/pix.json` | Mundo Pix: causas do PicPay, regras do Banco Central e as arestas de curadoria. |
| `server/seed/curadoria.json` | Nome curto e sinônimos de busca dos nós. |
| `server/scripts/build-seed.mjs` | Gera `cgov.json` a partir do CSV público. |

## API

Duas chamadas fazem tudo. As duas devolvem o mesmo formato.

**`POST /api/consult`**: o cliente falou.

```json
{ "sessionId": "…ou omita para começar uma conversa", "text": "Não estou conseguindo pagar a fatura do meu cartão de crédito" }
```

**`POST /api/visit`**: o agente (ou um clique) foi até um nó.

```json
{ "sessionId": "…", "nodeId": "pix:saldo-insuficiente", "status": "descartado" }
```

`status` é `consultado` (padrão, abre as relações do nó), `descartado`, `confirmado` ou `resolvido` (os três fecham o nó). Visitar um nó do tipo `tema` muda de tema. Visitar `more:<id>` mostra a próxima leva de vizinhos daquele nó.

**Resposta** (exemplo real, com a lista de nós abreviada):

```json
{
  "sessionId": "8fd72898-…",
  "trace": [
    { "node": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja", "via": null, "why": "tema" },
    { "node": "prob:nao-envio-atraso-do-boleto-ou-fatura-dificuldade-com-o-p", "via": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja", "why": "cliente" }
  ],
  "shift": null,
  "view": {
    "theme": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja",
    "past": [],
    "stats": { "visible": 6, "hidden": 43, "total": 143, "edges": 1094 },
    "nodes": [
      { "id": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja", "kind": "tema", "role": "ancora",
        "label": "Cartão de Crédito / Cartão de Débito / Cartão de Loja", "short": "Cartão",
        "w": 59953, "wCompany": 2269, "src": "cgov" },
      { "id": "prob:nao-envio-atraso-do-boleto-ou-fatura-dificuldade-com-o-p", "kind": "problema", "role": "foco",
        "label": "Não envio / atraso do boleto ou fatura / dificuldade com o pagamento", "short": "Fatura: dificuldade de pagar",
        "w": 1405, "wCompany": 28, "src": "cgov", "group": "Cobrança / Contestação",
        "p": 0.51, "factors": { "rel": 1, "freq": 0.04, "ctx": 0 },
        "parent": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja" },
      { "id": "more:tema:cartao-de-credito-cartao-de-debito-cartao-de-loja", "kind": "more", "short": "+43", "count": 43,
        "parent": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja", "role": "vizinho" }
    ],
    "links": [
      { "source": "tema:cartao-de-credito-cartao-de-debito-cartao-de-loja",
        "target": "prob:nao-envio-atraso-do-boleto-ou-fatura-dificuldade-com-o-p",
        "rel": "TEM_PROBLEMA", "w": 592, "wCompany": 24, "src": "cgov" }
    ]
  }
}
```

- `view` é o subgrafo que deve estar na tela agora. O frontend troca o que tinha por isso; a base inteira nunca vai para o browser.
- `trace` é a ordem em que os nós acendem neste passo. `via` é de onde o pulso parte.
- `shift` vem preenchido quando a conversa mudou de tema: `{ from, to, bridge: [ids], kind: "ponte" | "salto" }`.

Campos de um nó: `kind` (`tema`, `problema`, `causa`, `regra`, `more`), `role` (abaixo), `status`, `p` e `factors` (a nota de prioridade e as três parcelas), `parent` (quem o revelou), `w` e `wCompany` (reclamações no setor e do PicPay), `src` (fonte), `ref` (título e URL da fonte), `detail` (texto da fonte).

Valores de `why`: `tema`, `cliente`, `ponte`, `novo-tema`, e os quatro `status`.

**`GET /api/meta`** devolve as constantes da regra, as fontes e o tamanho da base. **`GET /api/health`** responde `{ "ok": true }`.

Erros voltam como `{ "error": "…" }` com status 400 (entrada inválida) ou 404 (nó inexistente).

## A regra de priorização

Tudo o que decide o que aparece está em `server/rank.mjs`.

```
prioridade = 50% relevância + 35% frequência + 15% continuidade
```

| Parcela | O que mede | De onde vem |
|---|---|---|
| Relevância | O quanto o nó casa com a última fala do cliente | `textScore` do Mongo, normalizado pelo melhor resultado |
| Frequência | A força da relação com o nó que o revelou | Reclamações reais do par, dividido pelo maior vizinho. Aresta de curadoria usa o `p` declarado |
| Continuidade | Se o nó já foi consultado nesta conversa | 1 no turno em que foi tocado, cai pela metade a cada turno |

Quatro limites mantêm a tela legível:

1. Um tema aberto mostra os **5** vizinhos de maior prioridade. O resto vira um nó `+N`.
2. Um nó visitado pelo agente abre **3** vizinhos.
3. A tela tem no máximo **12** nós, fora os `+N`. Quem sai primeiro é o vizinho de menor prioridade, e ele volta para o `+N` de quem o revelou.
4. Só as ligações estruturais são desenhadas: quem revelou quem, e a ponte. As outras relações reais entre nós visíveis ficam fora.

Papéis (`role`), que definem quem nunca é derrubado pelo teto:

| Papel | Significado | Protegido |
|---|---|---|
| `ancora` | O tema atual | sim |
| `foco` | Vizinho com relevância ≥ 0,5: o que o cliente disse | sim |
| `trilha` | Consultado pelo agente neste tema | sim |
| `ponte` | Liga o tema anterior ao novo | sim |
| `contexto` | Tema anterior, recolhido | sim |
| `vizinho` | Entrou pela nota de prioridade | não |

Para mudar o comportamento, mude os números de `RULE` e rode `npm test`.

## Antes do grafo: entender a demanda

O cliente pode chegar sem contexto, ou sem dizer nada. Enquanto não há tema, `view.state` diz em que ponto do funil a conversa está, e `view.nodes` traz hipóteses em vez do grafo.

| `view.state` | Quando | O card mostra | `view.ask` |
|---|---|---|---|
| `frio` | Nenhuma hipótese acima de 0,15 | O mapa geral: os 5 temas mais frequentes da base (`role: "mapa"`) | `open: true`: pergunta aberta |
| `hipoteses` | Há candidatos, mas fracos ou empatados | As hipóteses com a nota (`role: "hipotese"`, `p`, `why`) | `options`: os nomes para a pergunta dirigida |
| `ancorado` | A melhor passa de 0,35 e vence a segunda por 25% | O grafo | (ausente) |

A decisão está em `decideEntry` (`rank.mjs`). Três coisas alimentam a nota de cada hipótese:

- **A fala**, acumulada entre os turnos: a evidência anterior vale 80% a cada turno novo. "Não consigo pagar" seguido de "é a fatura do cartão" soma.
- **Problemas que existem em vários temas** votam nos temas em que são mais frequentes. É por isso que "não consigo pagar" vira Cartão, Pix e Conta.
- **Pistas do perfil** (`hints: [{ node, label }]` em `/api/consult`) somam 0,30 ao tema. Fica abaixo do piso de entrada de propósito: o perfil sugere, mas não decide sozinho.

`text` vazio em `/api/consult` significa "chegou sem dizer nada". Clicar numa hipótese (`visit` no tema) entra no grafo direto.

Depois de 2 perguntas (`MAX_ASKS`) o servidor segue com a melhor hipótese e marca `view.forced`. Se nem hipótese houver, `view.ask.handoff` vem `true`: é hora de passar para um humano.

O texto da pergunta é do agente. O servidor só diz se ela é aberta ou entre quais opções.

## Mudança de tema

Há dois jeitos de mudar de tema, e os dois passam por `enterTheme` em `server.mjs`.

**Pela fala do cliente.** Cada fala gera uma nota de entrada por tema. O tema citado pelo nome recebe a relevância, com 15% de desempate pela frequência real. Um nó que pertence a um único tema (uma causa do Pix, por exemplo) vota no tema dono com peso 0,6. A conversa só troca de tema se o novo vencer o atual por 25% (`SHIFT_MARGIN`) e passar do piso (`MIN_ENTRY`).

**Pela navegação.** Ao abrir um problema, os temas ligados a ele aparecem como vizinhos. São portas para outros mundos. Visitar uma delas troca de tema.

Na troca:

1. O servidor procura a **ponte**: o menor caminho do tema novo até algo que a conversa já conhecia (o tema antigo, o foco ou um nó consultado). Usa `$graphLookup` com até 3 saltos e uma busca em largura.
2. O tema antigo é recolhido para um único nó `contexto`. Os vizinhos dele saem da tela.
3. O tema novo abre com os 5 vizinhos de maior prioridade.
4. O `trace` acende do nó conhecido até o tema novo.

Se não houver caminho, `shift.kind` vem `"salto"` e a ligação é marcada como tal.

Voltar a um tema anterior restaura a trilha dele.

No cenário da demo: a cliente fala da fatura, o agente abre "Fatura: dificuldade de pagar" e o Pix aparece como porta. Quando ela diz que está pagando por Pix, o tema muda, "Fatura" vira a ponte, Cartão vira contexto e o mundo Pix abre com as causas.

## Modelo no MongoDB

Duas coleções, com `_id` em texto estável.

```js
// nodes
{ _id: "prob:nao-envio-atraso-do-boleto-ou-fatura-dificuldade-com-o-p", kind: "problema",
  label: "Não envio / atraso do boleto ou fatura / dificuldade com o pagamento",
  short: "Fatura: dificuldade de pagar", keywords: "pagar fatura vencimento …",
  w: 1405, wCompany: 28, group: "Cobrança / Contestação", src: "cgov" }

// edges
{ ends: ["tema:cartao-…", "prob:nao-envio-…"], rel: "TEM_PROBLEMA", w: 592, wCompany: 24, src: "cgov" }
{ ends: ["prob:nao-envio-…", "tema:pix"], rel: "PAGO_VIA", p: 0.9, src: "curadoria" }
```

A aresta guarda as duas pontas no array `ends`. Com um índice nesse campo ela é achada pelos dois lados, e o `$graphLookup` percorre o grafo sem direção usando `ends` tanto em `connectFromField` quanto em `connectToField`.

Índices: `edges { ends: 1 }` e um índice de texto em `nodes` (`short` peso 3, `keywords` peso 2, `label` peso 1, idioma português).

As cinco consultas estão em `db.mjs`: busca textual, vizinhança de um nó, alcance por `$graphLookup`, arestas entre os nós visíveis e documentos por id.

## De onde vêm os dados

| Fonte | O que entra | Onde |
|---|---|---|
| [consumidor.gov.br, dados abertos](https://www.consumidor.gov.br/pages/dadosabertos/externo/) (Senacon / MJSP) | 32 temas, 95 problemas e 1.075 relações da área "Serviços Financeiros". Peso = reclamações finalizadas em setembro de 2026: 207.483 no setor, 5.509 do PicPay | `seed/cgov.json` |
| [Central de Ajuda do PicPay](https://meajuda.picpay.com/hc/pt-br/articles/12114338559507-Por-que-n%C3%A3o-foi-poss%C3%ADvel-fazer-um-Pix-no-PicPay) | As 8 causas de "Não foi possível fazer um Pix", com o texto literal do artigo (versão de 29/09/2026) | `seed/pix.json` |
| Banco Central do Brasil, normativos do Pix | 6 regras: limite noturno, prazo de aumento de limite, aparelho não cadastrado, rejeição por fraude, bloqueio cautelar e MED | `seed/pix.json` |
| Curadoria | O nó-tema "Pix" e 5 arestas que ligam as bases entre si, como fatura ↔ Pix | `seed/pix.json` |

A taxonomia do consumidor.gov.br não tem Pix, então o mundo Pix vem das outras duas fontes. O que liga uma base à outra é curadoria: essas arestas não têm contagem e usam uma força declarada (`p`). No grafo elas aparecem tracejadas.

A ordem das 8 causas do Pix é a ordem em que o artigo do PicPay as lista. O Banco Central não publica contagem de rejeições por motivo, então não há frequência real para elas.

Para atualizar a base com outro mês:

```bash
# baixe "Dados - <Mês>/<Ano>" no portal e descompacte
cd server
node scripts/build-seed.mjs caminho/finalizadas_AAAA-MM.csv [outro-mes.csv ...]
```

O recorte por empresa é configurável: `COMPANY_MATCH=nubank COMPANY_LABEL=Nubank`.

Antes de uso externo, confira os termos de uso do portal de dados abertos e da Central de Ajuda. Eles não foram verificados aqui.

## Portar o frontend

`hugin-graph.js` exporta uma função:

```js
const grafo = await mountMemoryGraph(el, {
  api: '',                         // base da API
  onStep({ node, via, why, data, link }) { /* um nó acendeu: preencha o painel de detalhe */ },
  onView(view, shift) { /* o conjunto visível mudou: contadores e trilha de temas */ },
  reduceMotion: () => false,
});

await grafo.consult('não consigo pagar a fatura do cartão');
await grafo.visit('pix:nao-concluido');
await grafo.visit('pix:saldo-insuficiente', 'descartado');
grafo.reset();                     // nova conversa
```

Cada chamada resolve depois que a trilha terminou de acender, então dá para encadear com `await`. As chamadas entram numa fila: clique do usuário e roteiro não se atropelam.

Depende só do [force-graph](https://github.com/vasturiano/force-graph) 1.5x, servido em `/vendor/force-graph.min.js`. Num projeto com bundler, importe o pacote e passe em `opts.ForceGraph`.

Num componente React, monte no `useEffect`, guarde o retorno num `ref` e chame `destroy()` na limpeza. O estado do grafo fica no módulo; o componente só precisa do que chega em `onStep` e `onView`.

O módulo tem dois desenhos para os mesmos dados, trocáveis com `grafo.setMode('arvore' | 'rede')` ou `opts.mode`:

- **`arvore`** (padrão, aprovado): árvore fixa da esquerda para a direita. É o que os itens abaixo descrevem.
- **`rede`** (proposta alternativa): camadas por tipo de nó, como um diagrama de rede neural (Temas → Problemas → Causas → Regras). A espessura da sinapse é a frequência real da relação, e as demais relações reais entre os nós visíveis (`view.mesh`) aparecem como uma malha fraca. `layoutRede()` cuida das posições.

O que vale manter ao portar:

- **O layout é uma árvore fixa, sem física** (`layout()`). O tema fica à esquerda, o que ele revela fica uma coluna à direita, e o rótulo fica ao lado do nó. Um layout de força foi testado e descartado: os nós não paravam de se mexer e os rótulos ficavam pequenos.
- Irmãos ficam na ordem em que apareceram (`seen`), então ninguém troca de lugar quando entra um nó novo.
- Contexto e ponte ficam empilhados acima do tema: é o caminho por onde a conversa chegou.
- Nó novo nasce em quem o revelou e desliza uma vez até o lugar dele (`glide()`).
- A câmera (`frame()`) mantém o canto superior esquerdo fixo e só muda o zoom quando a árvore deixa de caber ou sobra 15% de espaço.
- Conectores em cotovelo (`route()`); o pulso viaja pelo conector.
- Aresta tracejada significa "sem contagem real". Não troque esse código visual por outra coisa.

O visual é chapado de propósito: sem brilho, sem partículas. O destaque de um nó que acende é um anel que se abre e um ponto que viaja pela aresta.

## Limites conhecidos

- **Quem escolhe o nó de entrada é uma busca textual.** Serve para a demo. No produto, o agente escolhe o nó, ou a busca vira semântica (Atlas Vector Search).
- **Sessões ficam na memória do processo**, com teto de 500. Com mais de uma instância, vão para uma coleção com TTL.
- **A resposta vem inteira por turno.** Quando o agente real emitir passos ao longo do tempo, troque por SSE: `playTrace` já consome um passo por vez.
- **O `$graphLookup` da ponte não restringe a busca.** Com esta base (1.094 arestas) leva cerca de 100 ms. Com base grande, use `restrictSearchWithMatch`: o estágio tem teto de 100 MB e ignora `allowDiskUse`.
- **A base tem um mês de dados.** `build-seed.mjs` aceita vários arquivos.
