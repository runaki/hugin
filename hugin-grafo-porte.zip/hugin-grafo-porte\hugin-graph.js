// hugin-graph.js — grafo de memória do Hugin (módulo portável, sem framework)
//
// É a peça para portar: fala com a API, desenha com force-graph e anima a trilha.
// O servidor decide O QUE aparece (regra de priorização); este módulo só decide COMO aparece.
//
//   <script src="/vendor/force-graph.min.js"></script>
//   const grafo = await mountMemoryGraph(div, { onStep, onView });
//   await grafo.consult('não consigo pagar a fatura do cartão');   // o cliente falou
//   await grafo.visit('pix:nao-concluido');                        // o agente navegou até um nó
//   await grafo.visit('pix:saldo-insuficiente', 'descartado');     // ...e registrou o que achou
//
// Cada chamada resolve só depois que a trilha terminou de acender, então dá para encadear com await.
//
// LAYOUT: árvore fixa, da esquerda para a direita, sem física. O tema fica à esquerda, o que ele revela
// fica uma coluna à direita, e assim por diante. Cada nó nasce no seu lugar e não se mexe mais; o rótulo
// fica ao lado do nó. A câmera só muda quando a árvore deixa de caber.
export const KIND_COLOR = { tema: '#2bbd66', problema: '#56b7ad', causa: '#d6a344', regra: '#9a8fdc', more: '#73817a' };
export const KIND_LABEL = { tema: 'Tema', problema: 'Problema', causa: 'Causa', regra: 'Regra' };

const INK = '#eef2ef', MUTED = '#9aa89f', PLATE = '#111714', PULSE = '#8fe6b0';
const SOLID = new Set(['ancora', 'foco', 'trilha', 'ponte']);     // papéis desenhados cheios
const LEFT = new Set(['ponte', 'contexto']);                      // o caminho por onde a conversa chegou: empilhado acima do tema
const DASHED = new Set(['curadoria', 'salto', 'more']);           // aresta tracejada = não é contagem real
const STALE = ['role', 'status', 'p', 'factors', 'parent', 'visited', 'count', 'why', 'hint'];
const COL = 146, ROW = 36, FONT = 12.5, LABEL_W = 122, PAD = 22;  // medidas da árvore, em unidades do grafo
// modo "rede": camadas por tipo de nó, como um diagrama de rede neural
const LAYER = { tema: 0, problema: 1, causa: 2, regra: 3 }, LAYER_NAME = ['TEMAS', 'PROBLEMAS', 'CAUSAS', 'REGRAS'];
const NCOL = 158, NROW = 62, HEAD = 28;
// antes do grafo: lista de hipóteses (ou o mapa geral)
const CAND_ROW = 46, CAND_W = 330;

const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const pair = (a, b) => (a < b ? a + '|' + b : b + '|' + a);
const idOf = x => (typeof x === 'object' ? x.id : x);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const radius = n => (n.kind === 'tema' ? 8 : n.kind === 'regra' ? 5 : 6);

/** Quebra o nome curto em até 2 linhas, no espaço mais perto do meio. */
function wrap(text, max = 18) {
  if (text.length <= max) return [text];
  const mid = text.length / 2;
  let cut = -1;
  for (let i = 0; i < text.length; i++) if (text[i] === ' ' && (cut < 0 || Math.abs(i - mid) < Math.abs(cut - mid))) cut = i;
  return cut < 0 ? [text] : [text.slice(0, cut), text.slice(cut + 1)];
}

/**
 * @param el      elemento que recebe o grafo (precisa ter largura e altura)
 * @param opts.api          base da API ('' = mesma origem)
 * @param opts.onStep       ({ node, via, why, data, link }) a cada nó que acende — use para o painel de detalhe
 * @param opts.onView       (view, shift) sempre que o conjunto visível muda — use para contadores e trilha de temas
 * @param opts.stepMs       duração de cada passo da trilha
 * @param opts.reduceMotion () => boolean: sem pulso nem anel, só troca de estado
 */
export async function mountMemoryGraph(el, opts = {}) {
  const { api = '', onStep, onView, stepMs = 950, reduceMotion = () => false, ForceGraph = globalThis.ForceGraph } = opts;
  let mode = opts.mode === 'rede' ? 'rede' : 'arvore';       // 'arvore' (padrão) | 'rede'
  let maxW = 1;
  const meta = await (await fetch(api + '/api/meta')).json();

  let sessionId = null, queue = Promise.resolve();
  let view = { nodes: [], links: [] }, byId = new Map();
  let bounds = null, zoom = 0, zoomTheme = null;
  const seen = new Map();                                  // ordem em que cada nó apareceu: irmãos nunca trocam de lugar
  const ringAt = new Map(), litAt = new Map(), pulses = [];
  const now = () => performance.now();
  const isLit = l => now() - (litAt.get(pair(idOf(l.source), idOf(l.target))) || -1e9) < 1700;

  // ------------------------------------------------------------ desenho
  /** Antes do grafo: uma hipótese (com a nota e de onde veio a pista) ou um item do mapa geral. */
  function drawCandidate(n, ctx) {
    const col = KIND_COLOR[n.kind] || MUTED, map = n.role === 'mapa', r = 7;
    ctx.save();
    ctx.globalAlpha = Math.min(1, (now() - (n.born || 0)) / 350);
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, 2 * Math.PI);
    ctx.fillStyle = map ? PLATE : rgba(col, 0.2); ctx.fill();
    if (map) ctx.setLineDash([3, 3]);
    ctx.strokeStyle = map ? rgba(MUTED, 0.9) : col; ctx.stroke(); ctx.setLineDash([]);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.font = `${map ? 500 : 600} ${FONT}px ${fontUI}`; ctx.fillStyle = map ? MUTED : INK;
    ctx.fillText(n.short || '', n.x + r + 8, n.y - 7);
    const why = n.why === 'perfil' ? 'perfil: ' + (n.hint || 'pista do cadastro') : n.why === 'fala' ? 'pela fala do cliente' : (n.w || 0).toLocaleString('pt-BR') + ' reclamações na base';
    ctx.font = `500 ${FONT - 2.5}px ${fontUI}`; ctx.fillStyle = rgba(MUTED, 0.9);
    ctx.fillText(why, n.x + r + 8, n.y + 8);
    if (!map) {                                            // a nota da hipótese
      const bx = n.x + CAND_W - 96, bw = 64;
      ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fillRect(bx, n.y - 2.5, bw, 5);
      ctx.fillStyle = col; ctx.fillRect(bx, n.y - 2.5, bw * Math.min(1, n.p || 0), 5);
      ctx.font = `600 ${FONT - 1.5}px ${fontUI}`; ctx.fillStyle = INK;
      ctx.fillText((n.p || 0).toFixed(2).replace('.', ','), bx + bw + 8, n.y + 0.5);
    }
    ctx.restore();
  }

  function drawNode(n, ctx) {
    if (n.role === 'hipotese' || n.role === 'mapa') return drawCandidate(n, ctx);
    const r = radius(n) + (mode === 'rede' ? 2 : 0), col = KIND_COLOR[n.kind] || MUTED;   // na rede o nó é um "neurônio": maior
    const faded = n.role === 'contexto' || n.status === 'descartado';
    ctx.save();
    ctx.globalAlpha = Math.min(1, (now() - (n.born || 0)) / 350) * (faded ? 0.5 : 1);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';

    const rede = mode === 'rede';
    if (n.kind === 'more') {                               // "+N": o que este nó ainda esconde
      ctx.font = `600 ${FONT - 1.5}px ${fontUI}`;
      const text = n.short + ' ocultos', w = ctx.measureText(text).width + 16, h = 20, x = rede ? n.x - w / 2 : n.x - 6;
      ctx.beginPath(); ctx.roundRect(x, n.y - h / 2, w, h, h / 2);
      ctx.fillStyle = PLATE; ctx.fill();
      ctx.setLineDash([3, 3]); ctx.lineWidth = 1; ctx.strokeStyle = rgba(MUTED, 0.9); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = MUTED; ctx.fillText(text, x + 8, n.y + 0.5);
      ctx.restore(); return;
    }
    // rótulo sobre uma placa da cor do painel. Árvore: ao lado do nó. Rede: à esquerda na 1ª camada e embaixo
    // do neurônio nas demais, para as sinapses ficarem livres.
    const side = !rede ? 'right' : n.tx === 0 ? 'left' : 'below';
    const lines = wrap(n.short || ''), lh = FONT * 1.18, hh = lh * lines.length;
    ctx.font = `${SOLID.has(n.role) ? 600 : 500} ${FONT}px ${fontUI}`;
    const w = Math.max(...lines.map(l => ctx.measureText(l).width));
    ctx.fillStyle = PLATE;
    if (side === 'right') ctx.fillRect(n.x - r - 3, n.y - hh / 2 - 2, w + 2 * r + 13, hh + 4);
    else if (side === 'left') ctx.fillRect(n.x - r - 10 - w, n.y - hh / 2 - 2, w + 6, hh + 4);
    else ctx.fillRect(n.x - w / 2 - 4, n.y + r + 4, w + 8, hh + 3);
    ctx.fillStyle = faded ? MUTED : INK;
    ctx.textAlign = side === 'right' ? 'left' : side === 'left' ? 'right' : 'center';
    const lx = side === 'right' ? n.x + r + 7 : side === 'left' ? n.x - r - 7 : n.x;
    const ly = side === 'below' ? n.y + r + 6 + lh / 2 : n.y - hh / 2 + lh / 2;
    lines.forEach((l, i) => ctx.fillText(l, lx, ly + i * lh + 0.5));

    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, 2 * Math.PI);
    ctx.fillStyle = SOLID.has(n.role) ? col : rgba(col, 0.2); ctx.fill();
    ctx.strokeStyle = col; ctx.stroke();
    if (n.status === 'confirmado' || n.status === 'resolvido') {      // causa achada / caso fechado: anel permanente
      ctx.beginPath(); ctx.arc(n.x, n.y, r + 3.4, 0, 2 * Math.PI); ctx.stroke();
    }
    if (n.status === 'descartado') {                                  // hipótese verificada e descartada: riscada
      ctx.beginPath(); ctx.moveTo(n.x - r * 0.72, n.y + r * 0.72); ctx.lineTo(n.x + r * 0.72, n.y - r * 0.72);
      ctx.strokeStyle = INK; ctx.stroke();
    }
    const t = (now() - (ringAt.get(n.id) || -1e9)) / 1100;            // anel que se abre quando o nó acende
    if (t < 1 && !reduceMotion()) {
      ctx.beginPath(); ctx.arc(n.x, n.y, r + 2 + t * 11, 0, 2 * Math.PI);
      ctx.strokeStyle = rgba(col, (1 - t) * 0.8); ctx.stroke();
    }
    ctx.restore();
  }

  function linkColor(l) {
    if (isLit(l)) return rgba(KIND_COLOR.tema, 0.95);
    const a = byId.get(idOf(l.source)), b = byId.get(idOf(l.target));
    const trail = a && b && [a, b].every(n => SOLID.has(n.role) || n.role === 'contexto');
    return trail ? 'rgba(150,175,160,.6)' : 'rgba(150,175,160,.3)';
  }

  function drawBackdrop(ctx) {
    if (!view.nodes.length) return;
    if (!view.theme) {                                     // antes do grafo: diz o que a lista é
      ctx.save();
      ctx.font = `600 9.5px ${fontUI}`; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = rgba(MUTED, 0.8);
      ctx.fillText(view.state === 'hipoteses' ? 'HIPÓTESES · NENHUMA VENCE AINDA' : 'SEM PISTA · MAPA GERAL DA BASE', -8, -CAND_ROW / 2 - 12);
      ctx.restore(); return;
    }
    if (mode !== 'rede') return;                           // só no modo rede: nome das camadas e a malha de relações reais
    ctx.save();
    ctx.font = `600 9.5px ${fontUI}`; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = rgba(MUTED, 0.75);
    ctx.textAlign = 'center';
    for (const c of new Set(view.nodes.map(n => Math.round(n.tx / NCOL)))) ctx.fillText(LAYER_NAME[c] || '', c * NCOL, -HEAD - 6);
    ctx.strokeStyle = 'rgba(150,175,160,.13)'; ctx.lineWidth = 0.8;
    for (const e of view.mesh || []) {
      const a = byId.get(e.source), b = byId.get(e.target);
      if (a && b) { ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
    }
    ctx.restore();
  }

  function glide(ctx) {                                    // nó desliza até o lugar dele uma vez e para
    drawBackdrop(ctx);
    const k = reduceMotion() ? 1 : 0.2;
    for (const n of view.nodes) {
      n.x += (n.tx - n.x) * k; n.y += (n.ty - n.y) * k;
      if (Math.abs(n.tx - n.x) < 0.3) n.x = n.tx;
      if (Math.abs(n.ty - n.y) < 0.3) n.y = n.ty;
      n.fx = n.x; n.fy = n.y;
    }
  }

  /** Conector em cotovelo: sai do pai na horizontal, desce num tronco pouco antes do filho e entra nele. */
  function route(a, b) {
    if (mode === 'rede' || Math.abs(a.x - b.x) < 1) return [[a.x, a.y], [b.x, b.y]];   // rede: sinapse reta. Árvore, mesma coluna: reta
    const [p, c] = a.x < b.x ? [a, b] : [b, a], tx = c.x - 18;
    const pts = [[p.x, p.y], [tx, p.y], [tx, c.y], [c.x, c.y]];
    return a === p ? pts : pts.reverse();
  }
  function drawLink(l, ctx) {
    const a = l.source, b = l.target;
    if (typeof a !== 'object' || typeof b !== 'object') return;
    const pts = route(a, b);
    ctx.save();
    ctx.globalAlpha = Math.min(1, (now() - Math.max(a.born || 0, b.born || 0)) / 350);
    ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    // rede: a espessura da sinapse é a frequência real da relação
    const base = mode === 'rede' && l.w ? 1 + 3.5 * Math.sqrt(l.w / maxW) : 1.2;
    ctx.strokeStyle = linkColor(l); ctx.lineWidth = isLit(l) ? Math.max(2.2, base) : base; ctx.lineJoin = 'round';
    ctx.setLineDash(DASHED.has(l.src) ? [4, 4] : []);
    ctx.stroke(); ctx.restore();
  }

  function drawPulses(ctx) {                               // o ponto que viaja de um nó ao outro, pelo conector
    for (let i = pulses.length - 1; i >= 0; i--) {
      const p = pulses[i], t = (now() - p.t0) / p.dur, a = byId.get(p.from), b = byId.get(p.to);
      if (t >= 1 || !a || !b) { pulses.splice(i, 1); continue; }
      const pts = route(a, b), seg = pts.slice(1).map((q, j) => Math.hypot(q[0] - pts[j][0], q[1] - pts[j][1]));
      let d = t * t * (3 - 2 * t) * seg.reduce((s, x) => s + x, 0), j = 0;
      while (j < seg.length - 1 && d > seg[j]) d -= seg[j++];
      const f = seg[j] ? d / seg[j] : 0;
      ctx.beginPath(); ctx.arc(pts[j][0] + (pts[j + 1][0] - pts[j][0]) * f, pts[j][1] + (pts[j + 1][1] - pts[j][1]) * f, 3.4, 0, 2 * Math.PI);
      ctx.fillStyle = PULSE; ctx.fill();
    }
  }

  const fontUI = getComputedStyle(el).fontFamily || 'sans-serif';
  const fg = new ForceGraph(el)
    .backgroundColor('rgba(0,0,0,0)')
    .nodeId('id')
    .nodeLabel(n => n.label || (n.kind === 'more' ? `${n.count} relações fora da tela — clique para ver mais` : ''))
    .nodeCanvasObject(drawNode)
    .nodePointerAreaPaint((n, color, ctx) => {             // o rótulo também é clicável
      ctx.fillStyle = color;
      if (!view.theme) ctx.fillRect(n.x - 10, n.y - CAND_ROW / 2 + 3, CAND_W, CAND_ROW - 6);     // hipótese: a linha toda escolhe
      else if (mode !== 'rede') ctx.fillRect(n.x - 10, n.y - ROW / 2 + 2, LABEL_W + 10, ROW - 4);
      else if (n.tx === 0 && n.kind !== 'more') ctx.fillRect(n.x - LABEL_W - 10, n.y - 16, LABEL_W + 22, 32);
      else ctx.fillRect(n.x - 58, n.y - 14, 116, 52);
    })
    .linkCanvasObject(drawLink)
    .onRenderFramePre(glide)
    .onRenderFramePost(drawPulses)
    .autoPauseRedraw(false)              // o anel e o pulso animam com o layout parado
    .cooldownTicks(0)                    // sem física: a posição vem de layout()
    .enableNodeDrag(false)
    .minZoom(0.3).maxZoom(3)
    .onNodeClick(n => handle.visit(n.id));

  // ------------------------------------------------------------ layout
  /** Dá a cada nó a posição final (tx, ty). Irmãos ficam na ordem em que apareceram, então ninguém troca de lugar. */
  function layout(v, nodes) {
    for (const n of nodes) if (!seen.has(n.id)) seen.set(n.id, seen.size);
    if (!v.theme) {                                        // antes do grafo: lista, na ordem de nota que o servidor mandou
      nodes.forEach((n, i) => { n.tx = 0; n.ty = i * CAND_ROW; });
      return { x0: -14, y0: -CAND_ROW / 2 - 26, x1: CAND_W, y1: nodes.length * CAND_ROW - CAND_ROW / 2 };
    }
    if (mode === 'rede') return layoutRede(v, nodes);
    const left = nodes.filter(n => LEFT.has(n.role)).sort((a, b) => (a.role === b.role ? seen.get(a.id) - seen.get(b.id) : a.role === 'contexto' ? -1 : 1));
    const leftIds = new Set(left.map(n => n.id)), kids = new Map();
    for (const n of nodes) {
      if (n.id === v.theme || leftIds.has(n.id)) continue;
      const parent = byId.has(n.parent) && !leftIds.has(n.parent) ? n.parent : v.theme;
      (kids.get(parent) || kids.set(parent, []).get(parent)).push(n);
    }
    for (const list of kids.values()) list.sort((a, b) => (a.kind === 'more') - (b.kind === 'more') || seen.get(a.id) - seen.get(b.id));
    let row = 0, depthMax = 0;
    const place = (n, depth) => {                          // o primeiro filho fica na linha do pai; os demais descem
      n.tx = depth * COL; n.ty = row * ROW; depthMax = Math.max(depthMax, depth);
      const list = kids.get(n.id);
      if (!list) { row++; return; }
      for (const k of list) place(k, depth + 1);
    };
    const root = byId.get(v.theme);
    if (root) place(root, 0);
    left.forEach((n, i) => { n.tx = 0; n.ty = (i - left.length) * ROW * 1.25; });   // contexto e ponte: empilhados acima do tema
    return { x0: -14, y0: -left.length * ROW * 1.25 - ROW / 2, x1: depthMax * COL + LABEL_W + 14, y1: Math.max(1, row) * ROW - ROW / 2 };
  }

  /**
   * Modo rede: uma camada por tipo de nó (Temas → Problemas → Causas → Regras), neurônios empilhados a partir
   * do topo na ordem em que apareceram. Quem entra vai para o fim da camada, então ninguém muda de lugar.
   */
  function layoutRede(v, nodes) {
    const cols = new Map();
    for (const n of nodes) {
      let c = LAYER[n.kind];
      if (n.kind === 'more') {                             // o "+N" fica na camada do que ele esconde
        const parent = byId.get(n.parent), doors = nodes.some(k => k.parent === n.parent && k.kind === 'tema');
        c = parent?.kind === 'problema' && doors ? 0 : Math.min(3, (LAYER[parent?.kind] ?? 0) + 1);
      }
      (cols.get(c) || cols.set(c, []).get(c)).push(n);
    }
    const rank = n => (n.id === v.theme ? 0 : n.role === 'contexto' ? 1 : n.kind === 'more' ? 3 : 2);
    let rows = 1, last = 0;
    for (const [c, list] of cols) {
      list.sort((a, b) => rank(a) - rank(b) || seen.get(a.id) - seen.get(b.id));
      list.forEach((n, i) => { n.tx = c * NCOL; n.ty = i * NROW; });
      rows = Math.max(rows, list.length); last = Math.max(last, c);
    }
    // sobra à esquerda para os rótulos da 1ª camada, e embaixo para os rótulos sob os neurônios
    return { x0: -LABEL_W - 22, y0: -HEAD - 22, x1: last * NCOL + 70, y1: (rows - 1) * NROW + 46 };
  }

  /**
   * Câmera: o canto superior esquerdo da árvore fica fixo. O zoom só muda quando a árvore deixa de caber
   * ou quando sobra bastante espaço (15%) — não a cada nó que entra.
   */
  function frame(reset) {
    if (!bounds || !el.clientWidth) return;
    const W = el.clientWidth, H = el.clientHeight;
    const fitK = Math.min((W - 2 * PAD) / (bounds.x1 - bounds.x0), (H - 2 * PAD) / (bounds.y1 - bounds.y0), 1.5);
    const k = reset || !zoom || fitK < zoom || fitK > zoom * 1.15 ? fitK : zoom;
    const ms = reduceMotion() || !zoom ? 0 : 450;
    zoom = k;
    fg.zoom(k, ms);
    fg.centerAt(bounds.x0 + (W / 2 - PAD) / k, bounds.y0 + (H / 2 - PAD) / k, ms);
  }
  const ro = new ResizeObserver(() => { if (el.clientWidth && el.clientHeight) { fg.width(el.clientWidth).height(el.clientHeight); frame(true); } });
  ro.observe(el);

  // ------------------------------------------------------------ dados
  /** Troca o conjunto visível. Quem já estava na tela mantém o objeto (e portanto o lugar). */
  function apply(v) {
    const before = byId;
    const nodes = v.nodes.map(n => {
      const old = before.get(n.id);
      if (old) { for (const k of STALE) delete old[k]; return Object.assign(old, n); }
      return { ...n, born: now() };
    });
    byId = new Map(nodes.map(n => [n.id, n]));
    bounds = nodes.length ? layout(v, nodes) : null;
    for (const n of nodes) if (n.x == null) {                // nó novo nasce em quem o revelou e desliza até o lugar
      const from = before.get(n.parent) || before.get(v.theme);
      n.x = from ? from.x : n.tx; n.y = from ? from.y : n.ty;
    }
    view = { ...v, nodes, links: v.links.map(l => ({ ...l })) };
    maxW = Math.max(1, ...view.links.map(l => l.w || 0));
    fg.graphData({ nodes, links: view.links });
    const changed = v.theme !== zoomTheme;                   // tema novo = árvore nova: reenquadra do zero
    zoomTheme = v.theme;
    frame(changed);
  }

  async function playTrace(trace) {
    for (const step of trace) {
      const data = byId.get(step.node);
      if (!data) continue;
      const calm = reduceMotion();
      if (step.via && byId.has(step.via) && !calm) {
        pulses.push({ from: step.via, to: step.node, t0: now(), dur: stepMs * 0.55 });
        litAt.set(pair(step.via, step.node), now());
        await sleep(stepMs * 0.55);
      }
      ringAt.set(step.node, now());
      const link = step.via ? view.links.find(l => pair(idOf(l.source), idOf(l.target)) === pair(step.via, step.node)) : null;
      onStep?.({ ...step, data, link });
      await sleep(calm ? 250 : stepMs * 0.6);
    }
  }

  async function call(path, body) {
    const r = await fetch(api + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId, ...body }) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || r.statusText);
    sessionId = j.sessionId;
    apply(j.view);
    onView?.(j.view, j.shift);
    await playTrace(j.trace);
    return j;
  }
  // uma chamada por vez: clique do usuário e roteiro não se atropelam
  const enqueue = fn => { const p = queue.then(fn); queue = p.catch(() => {}); return p; };

  const handle = {
    meta,
    /**
     * O cliente falou: ancora no tema, prioriza e detecta mudança de tema.
     * Texto vazio = chegou sem dizer nada. `hints` = pistas do perfil [{ node, label }], enviadas uma vez.
     * Enquanto a demanda não é entendida, view.state é 'frio' ou 'hipoteses' e view.ask diz o que perguntar.
     */
    consult: (text = '', hints) => enqueue(() => call('/api/consult', { text, hints })),
    /** O agente (ou um clique) foi até um nó. status: 'consultado' | 'descartado' | 'confirmado' | 'resolvido'. */
    visit: (nodeId, status) => enqueue(() => call('/api/visit', { nodeId, status })),
    /** Nova conversa. */
    reset: () => enqueue(async () => {
      sessionId = null; seen.clear(); ringAt.clear(); litAt.clear(); zoom = 0; zoomTheme = null;
      apply({ nodes: [], links: [], theme: null, past: [], stats: { visible: 0, hidden: 0, total: meta.stats.nodes, edges: meta.stats.edges } });
      onView?.(view, null);
    }),
    get view() { return view; },
    get mode() { return mode; },
    /** Troca o desenho sem refazer a conversa: 'arvore' ou 'rede'. */
    setMode(m) {
      mode = m === 'rede' ? 'rede' : 'arvore';
      if (view.nodes.length) { bounds = layout(view, view.nodes); frame(true); }
    },
    destroy() { ro.disconnect(); fg._destructor(); },
  };
  return handle;
}
