// Camada MongoDB: conexão, carga do seed, índices e as 5 consultas que o grafo usa.
//
// Modelo (duas coleções, _id string estável):
//   nodes { _id, kind: 'tema'|'problema'|'causa', label, short, keywords, w, wCompany, src, tema?, group?, ref?, detail? }
//   edges { ends: [idA, idB], rel, w?, wCompany?, p?, src }
// `ends` é um array de 2 ids: com um índice multikey a aresta é achada pelos dois lados,
// e o $graphLookup percorre o grafo sem direção usando o mesmo campo nas duas pontas.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { MongoClient } from 'mongodb';

const SEED_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'seed');
const SEED_FILES = ['cgov.json', 'pix.json'];

/** Usa MONGODB_URI (Atlas/local). Sem ela, sobe um mongod real e efêmero só para a demo. */
export async function connect() {
  let uri = process.env.MONGODB_URI, mem = null;
  if (!uri) {
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    // o mongod leva ~20s para subir do zero no Windows; o padrão da lib desiste em 10s
    mem = await MongoMemoryServer.create({ instance: { launchTimeout: 90_000 } });
    uri = mem.getUri();
  }
  const client = await new MongoClient(uri).connect();
  return { client, mem, db: client.db(process.env.MONGODB_DB || 'hugin'), ephemeral: !!mem };
}

export function readSeed() {
  const nodes = [], edges = [], sources = [];
  for (const f of SEED_FILES) {
    const file = path.join(SEED_DIR, f);
    if (!fs.existsSync(file)) continue;
    const s = JSON.parse(fs.readFileSync(file, 'utf8'));
    sources.push(...[].concat(s.meta));
    nodes.push(...s.nodes);
    edges.push(...s.edges);
  }
  return { nodes, edges, sources };
}

/** Carrega o seed se a base estiver vazia (ou sempre, com force) e garante os índices. */
export async function seed(db, { force = false } = {}) {
  const nodes = db.collection('nodes'), edges = db.collection('edges'), meta = db.collection('meta');
  if (force || !(await nodes.estimatedDocumentCount())) {
    const s = readSeed();
    const ids = new Set(s.nodes.map(n => n._id));
    const orphan = s.edges.find(e => !e.ends.every(id => ids.has(id)));
    if (orphan) throw new Error(`aresta aponta para nó inexistente: ${orphan.ends.join(' — ')}`);
    await Promise.all([nodes.deleteMany({}), edges.deleteMany({}), meta.deleteMany({})]);
    await nodes.insertMany(s.nodes);
    await edges.insertMany(s.edges);
    await meta.insertMany(s.sources.map(src => ({ ...src, _id: src.id })));
  }
  await edges.createIndex({ ends: 1 });
  await nodes.createIndex(
    { short: 'text', keywords: 'text', label: 'text' },
    { default_language: 'portuguese', weights: { short: 3, keywords: 2, label: 1 }, name: 'busca' },
  );
}

/** 1. Entrada: o que a mensagem do cliente casa na base (busca textual com stemming em português). */
export function searchNodes(db, text, limit = 25) {
  return db.collection('nodes')
    .find({ $text: { $search: text } }, { projection: { kind: 1, tema: 1, w: 1, score: { $meta: 'textScore' } } })
    .sort({ score: { $meta: 'textScore' } }).limit(limit).toArray();
}

/** 2. Vizinhança de um nó: [{ id, edge }] — é o que a regra de priorização ordena. */
export async function neighborsOf(db, id) {
  const edges = await db.collection('edges').find({ ends: id }).toArray();
  return edges.map(e => ({ id: e.ends[0] === id ? e.ends[1] : e.ends[0], edge: e }));
}

/**
 * 3. Ponte entre temas: todas as arestas alcançáveis a partir de `from` em até `maxDepth+1` saltos.
 * ponytail: sem restrictSearchWithMatch — a base tem ~1,1 mil arestas. Com base grande, restrinja
 * por `src`/`rel` aqui: o $graphLookup tem teto de 100 MB por estágio e ignora allowDiskUse.
 */
export async function reach(db, from, maxDepth = 2) {
  const [doc] = await db.collection('nodes').aggregate([
    { $match: { _id: from } },
    { $graphLookup: { from: 'edges', startWith: '$_id', connectFromField: 'ends', connectToField: 'ends', as: 'reach', maxDepth, depthField: 'depth' } },
    { $project: { reach: { ends: 1, depth: 1 } } },
  ]).toArray();
  return (doc?.reach || []).sort((a, b) => a.depth - b.depth).map(e => e.ends);
}

/** 4. Arestas entre os nós visíveis (para desenhar só as ligações que importam). */
export async function edgesAmong(db, ids) {
  const set = new Set(ids);
  const edges = await db.collection('edges').find({ ends: { $in: ids } }).toArray();
  return edges.filter(e => e.ends.every(id => set.has(id)));
}

/** 5. Documentos dos nós visíveis. */
export function nodesById(db, ids) {
  return db.collection('nodes').find({ _id: { $in: ids } }).toArray();
}

export async function stats(db) {
  const nodes = db.collection('nodes');
  const [total, edges, byKind, sources, maxTema] = await Promise.all([
    nodes.estimatedDocumentCount(),
    db.collection('edges').estimatedDocumentCount(),
    nodes.aggregate([{ $group: { _id: '$kind', n: { $sum: 1 } } }]).toArray(),
    db.collection('meta').find().toArray(),
    nodes.find({ kind: 'tema', w: { $gt: 0 } }, { projection: { w: 1 } }).sort({ w: -1 }).limit(5).toArray(),
  ]);
  // topTemas: o "mapa geral" mostrado quando a conversa começa sem pista nenhuma
  return { nodes: total, edges, byKind: Object.fromEntries(byKind.map(k => [k._id, k.n])), sources, maxTemaW: maxTema[0]?.w || 1, topTemas: maxTema };
}
