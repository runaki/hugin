// A REGRA DE PRIORIZAÇÃO do grafo de memória — funções puras, sem Mongo.
//
// O que aparece na tela é decidido aqui, e só aqui:
//
//   prioridade(nó) = 50% RELEVÂNCIA   o quanto o nó casa com o que o cliente acabou de dizer
//                  + 35% FREQUÊNCIA   força real da relação (nº de reclamações do par no dado público)
//                  + 15% CONTINUIDADE o nó já foi consultado nesta conversa? (cai pela metade a cada turno)
//
// Em volta dessa nota, quatro limites deixam o grafo legível:
//   - tema aberto mostra só os K_ANCHOR vizinhos de maior prioridade; o resto vira um nó "+N"
//   - nó visitado pelo agente abre só K_VISIT vizinhos
//   - a tela nunca passa de MAX_VISIBLE nós; quem sai primeiro é o vizinho de menor prioridade
//   - âncora, trilha (o que o agente consultou), ponte e contexto anterior nunca são derrubados
//
// Mudar o comportamento do grafo = mudar os números de RULE.
export const RULE = Object.freeze({
  W_REL: 0.5, W_FREQ: 0.35, W_CTX: 0.15,
  K_ANCHOR: 5,        // vizinhos mostrados ao abrir um tema
  K_VISIT: 3,         // vizinhos mostrados quando o agente visita um nó
  MAX_VISIBLE: 12,    // teto de nós na tela (fora os "+N")
  FOCUS_REL: 0.5,     // relevância a partir da qual o nó é "o que o cliente disse"
  MIN_ENTRY: 0.35,    // abaixo disso a mensagem não ancora em tema nenhum
  SHIFT_MARGIN: 1.25, // novo tema precisa vencer o atual por 25% para haver troca
  PRIOR_WEIGHT: 0.15, // desempate de tema pela frequência real
  MAX_PAST_THEMES: 2, // quantos temas anteriores ficam como "contexto"
  // antes de entrar no grafo (demanda ainda não entendida)
  AMBIG_FLOOR: 0.15,  // abaixo disso nem é hipótese: a conversa está "fria"
  HINT_VOTE: 0.3,     // peso de uma pista do perfil do cliente — de propósito abaixo de MIN_ENTRY: perfil sozinho não decide
  EVID_DECAY: 0.8,    // quanto da evidência de falas anteriores sobrevive a cada turno
  MAX_ASKS: 2,        // perguntas de desambiguação antes de seguir com a melhor hipótese
  MAX_CANDIDATES: 5,  // hipóteses mostradas no card
});

const round = x => Math.round(x * 100) / 100;

/** Força da relação, 0..1. Contagem real -> relativa ao maior vizinho; curadoria -> `p` declarado. */
export function freqOf(edge, maxW) {
  if (edge.p != null) return edge.p;
  return maxW > 0 ? edge.w / maxW : 0;
}

/** Continuidade, 0..1: 1 no turno em que o nó foi tocado, metade a cada turno seguinte. */
export function ctxOf(touchedTurn, turn) {
  return touchedTurn == null ? 0 : 0.5 ** (turn - touchedTurn);
}

export function score({ rel, freq, ctx }) {
  return RULE.W_REL * rel + RULE.W_FREQ * freq + RULE.W_CTX * ctx;
}

/**
 * Ordena os vizinhos de um nó e devolve os `k` de maior prioridade.
 * @param neighbors [{ id, edge:{w,p} }]
 * @param rel Map(id -> 0..1) relevância textual da última mensagem do cliente
 * @param touched Map(id -> {turn}) nós já consultados na conversa
 * @param exclude Set(id) nós que já estão na tela: não gastam vaga, mas contam para o maior peso
 * @returns { shown:[{id, p, factors}], hidden:number }
 */
export function prioritize(neighbors, { rel, touched, turn, k, exclude = new Set() }) {
  const maxW = Math.max(0, ...neighbors.map(n => n.edge.w || 0));
  const ranked = neighbors.filter(n => !exclude.has(n.id)).map(n => {
    const factors = {
      rel: round(rel.get(n.id) || 0),
      freq: round(freqOf(n.edge, maxW)),
      ctx: round(ctxOf(touched.get(n.id)?.turn, turn)),
    };
    return { id: n.id, p: round(score(factors)), factors };
  }).sort((a, b) => b.p - a.p || a.id.localeCompare(b.id));
  return { shown: ranked.slice(0, k), hidden: Math.max(0, ranked.length - k) };
}

/**
 * Decide se a conversa continua no tema atual ou muda de mundo.
 * @param current id do tema atual (ou null)
 * @param scores [{id, score}] nota de entrada de cada tema para a mensagem
 */
export function decideTheme(current, scores) {
  const best = [...scores].sort((a, b) => b.score - a.score)[0];
  if (!best || best.score < RULE.MIN_ENTRY) return { theme: current, shifted: false };
  if (!current) return { theme: best.id, shifted: false };
  if (best.id === current) return { theme: current, shifted: false };
  const cur = scores.find(s => s.id === current)?.score || 0;
  return best.score >= cur * RULE.SHIFT_MARGIN ? { theme: best.id, shifted: true } : { theme: current, shifted: false };
}

/**
 * Antes de haver tema: a demanda já está entendida o bastante para entrar no grafo?
 *   frio       nenhuma hipótese acima do piso        -> mapa geral + pergunta aberta
 *   hipoteses  há candidatos, mas fracos ou empatados -> pergunta dirigida
 *   ancorado   um candidato passa do piso de entrada e vence o segundo com margem (ou acabaram as perguntas)
 * @param cands [{id, score}] em ordem decrescente de nota (evidência acumulada das falas + pistas do perfil)
 * @param asks  quantas perguntas de desambiguação já foram feitas
 */
export function decideEntry(cands, asks) {
  const top = cands[0];
  if (!top || top.score < RULE.AMBIG_FLOOR) return { state: 'frio' };
  if (top.score >= RULE.MIN_ENTRY && top.score >= (cands[1]?.score || 0) * RULE.SHIFT_MARGIN) return { state: 'ancorado', theme: top.id };
  if (asks >= RULE.MAX_ASKS) return { state: 'ancorado', theme: top.id, forced: true };
  return { state: 'hipoteses' };
}

const PROTECTED = new Set(['ancora', 'foco', 'trilha', 'ponte', 'contexto']);

/** Aplica o teto de nós: derruba vizinhos de menor prioridade; papéis protegidos nunca saem. */
export function prune(nodes, max) {
  const droppable = nodes.filter(n => !PROTECTED.has(n.role)).sort((a, b) => a.p - b.p || a.id.localeCompare(b.id));
  const dropped = droppable.slice(0, Math.max(0, nodes.length - max)).map(n => n.id);
  const gone = new Set(dropped);
  return { keep: nodes.filter(n => !gone.has(n.id)).map(n => n.id), dropped };
}

/**
 * Ponte entre temas: menor caminho de `from` até qualquer nó de `targets` (BFS).
 * Como a busca para no primeiro alvo alcançado, um nó já consultado que esteja no
 * caminho encerra a ponte nele — a ponte "pousa" no que o agente já conhecia.
 * @param edges [[a, b], ...] não direcionado
 */
export function shortestPath(edges, from, targets) {
  const adj = new Map();
  const link = (a, b) => (adj.get(a) || adj.set(a, []).get(a)).push(b);
  for (const [a, b] of edges) { link(a, b); link(b, a); }
  const prev = new Map([[from, null]]);
  for (const queue = [from]; queue.length;) {
    const cur = queue.shift();
    if (cur !== from && targets.has(cur)) {
      const path = [];
      for (let n = cur; n != null; n = prev.get(n)) path.unshift(n);
      return path;
    }
    for (const nb of adj.get(cur) || []) if (!prev.has(nb)) { prev.set(nb, cur); queue.push(nb); }
  }
  return null;
}
