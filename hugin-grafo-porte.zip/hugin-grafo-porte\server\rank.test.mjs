// node --test   (a regra de priorização é pura: não precisa de Mongo para testar)
import test from 'node:test';
import assert from 'node:assert/strict';
import { RULE, freqOf, ctxOf, score, prioritize, decideTheme, decideEntry, prune, shortestPath } from './rank.mjs';

test('pesos da regra somam 1', () => {
  assert.equal(RULE.W_REL + RULE.W_FREQ + RULE.W_CTX, 1);
});

test('frequência: contagem real é relativa ao maior vizinho; curadoria usa p declarado', () => {
  assert.equal(freqOf({ w: 50 }, 200), 0.25);
  assert.equal(freqOf({ p: 0.9 }, 200), 0.9);        // aresta de curadoria não tem contagem
  assert.equal(freqOf({ w: 0 }, 0), 0);
});

test('continuidade cai pela metade a cada turno e é zero para nó nunca tocado', () => {
  assert.equal(ctxOf(undefined, 3), 0);
  assert.equal(ctxOf(3, 3), 1);
  assert.equal(ctxOf(2, 3), 0.5);
  assert.equal(ctxOf(1, 3), 0.25);
});

test('prioridade = 50% relevância + 35% frequência + 15% continuidade', () => {
  assert.equal(score({ rel: 1, freq: 0, ctx: 0 }), 0.5);
  assert.equal(score({ rel: 0, freq: 1, ctx: 0 }), 0.35);
  assert.equal(score({ rel: 0, freq: 0, ctx: 1 }), 0.15);
});

test('prioritize: o que o cliente disse vence o que é só frequente; resto vira "+N"', () => {
  const neighbors = [
    { id: 'juros', edge: { w: 1000 } },      // o mais frequente, mas o cliente não falou disso
    { id: 'fatura', edge: { w: 20 } },       // raro, mas é exatamente o que o cliente disse
    { id: 'tarifa', edge: { w: 600 } },
    { id: 'sac', edge: { w: 300 } },
  ];
  const out = prioritize(neighbors, { rel: new Map([['fatura', 1]]), touched: new Map(), turn: 1, k: 2 });
  assert.deepEqual(out.shown.map(n => n.id), ['fatura', 'juros']);
  assert.equal(out.hidden, 2);
  assert.deepEqual(out.shown[0].factors, { rel: 1, freq: 0.02, ctx: 0 });
});

test('prioritize: nó já consultado na conversa ganha continuidade', () => {
  const neighbors = [{ id: 'a', edge: { w: 100 } }, { id: 'b', edge: { w: 90 } }];
  const out = prioritize(neighbors, { rel: new Map(), touched: new Map([['b', { turn: 2 }]]), turn: 2, k: 1 });
  assert.equal(out.shown[0].id, 'b');
});

test('prioritize: nó já na tela não gasta vaga, mas segue valendo como referência de frequência', () => {
  const neighbors = [{ id: 'ancora', edge: { w: 1000 } }, { id: 'a', edge: { w: 500 } }, { id: 'b', edge: { w: 100 } }];
  const out = prioritize(neighbors, { rel: new Map(), touched: new Map(), turn: 1, k: 1, exclude: new Set(['ancora']) });
  assert.deepEqual(out.shown.map(n => n.id), ['a']);
  assert.equal(out.shown[0].factors.freq, 0.5);        // 500/1000, e não 500/500
  assert.equal(out.hidden, 1);
});

test('tema: primeiro tema entra direto; mensagem fraca não muda nada', () => {
  assert.deepEqual(decideTheme(null, [{ id: 'cartao', score: 0.9 }]), { theme: 'cartao', shifted: false });
  assert.deepEqual(decideTheme('cartao', [{ id: 'pix', score: 0.1 }]), { theme: 'cartao', shifted: false });
  assert.deepEqual(decideTheme('cartao', []), { theme: 'cartao', shifted: false });
});

test('tema: só muda se o novo tema vencer o atual com margem', () => {
  // cliente ainda fala de cartão e cita pix de passagem: fica
  assert.equal(decideTheme('cartao', [{ id: 'pix', score: 0.6 }, { id: 'cartao', score: 0.55 }]).shifted, false);
  // agora o assunto é pix: muda
  assert.deepEqual(decideTheme('cartao', [{ id: 'pix', score: 0.9 }, { id: 'cartao', score: 0.2 }]), { theme: 'pix', shifted: true });
  // tema atual nem aparece na mensagem: muda
  assert.equal(decideTheme('cartao', [{ id: 'pix', score: 0.8 }]).shifted, true);
});

test('entrada: sem pista fica frio; pista fraca ou empate vira hipóteses; vencedor claro entra no grafo', () => {
  assert.deepEqual(decideEntry([], 0), { state: 'frio' });
  assert.deepEqual(decideEntry([{ id: 'cartao', score: 0.1 }], 0), { state: 'frio' });                 // abaixo do piso de hipótese
  assert.deepEqual(decideEntry([{ id: 'cartao', score: 0.3 }], 0), { state: 'hipoteses' });            // pista do perfil sozinha não decide
  assert.deepEqual(decideEntry([{ id: 'cartao', score: 0.5 }, { id: 'pix', score: 0.45 }], 0), { state: 'hipoteses' });   // empate
  assert.deepEqual(decideEntry([{ id: 'cartao', score: 0.8 }, { id: 'pix', score: 0.3 }], 0), { state: 'ancorado', theme: 'cartao' });
});

test('entrada: depois de 2 perguntas segue com a melhor hipótese em vez de interrogar', () => {
  const tie = [{ id: 'cartao', score: 0.5 }, { id: 'pix', score: 0.45 }];
  assert.deepEqual(decideEntry(tie, 1), { state: 'hipoteses' });
  assert.deepEqual(decideEntry(tie, RULE.MAX_ASKS), { state: 'ancorado', theme: 'cartao', forced: true });
  assert.deepEqual(decideEntry([], RULE.MAX_ASKS), { state: 'frio' });                                // sem hipótese não há o que forçar
});

test('prune: respeita o teto e nunca derruba âncora, trilha, ponte ou contexto', () => {
  const nodes = [
    { id: 'ancora', role: 'ancora', p: 0 }, { id: 'ponte', role: 'ponte', p: 0 },
    { id: 'trilha', role: 'trilha', p: 0 }, { id: 'ctx', role: 'contexto', p: 0 },
    { id: 'v1', role: 'vizinho', p: 0.4 }, { id: 'v2', role: 'vizinho', p: 0.1 }, { id: 'v3', role: 'vizinho', p: 0.3 },
  ];
  const { keep, dropped } = prune(nodes, 5);
  assert.deepEqual(dropped, ['v2', 'v3']);              // os de menor prioridade saem primeiro
  assert.equal(keep.length, 5);
  for (const id of ['ancora', 'ponte', 'trilha', 'ctx']) assert.ok(keep.includes(id));
  // protegidos acima do teto: ninguém é derrubado à força
  assert.equal(prune(nodes.slice(0, 4), 2).dropped.length, 0);
});

test('ponte: caminho mais curto entre o tema novo e o que já estava na conversa', () => {
  const edges = [['cartao', 'fatura'], ['fatura', 'pix'], ['cartao', 'juros'], ['juros', 'emprestimo'], ['emprestimo', 'x'], ['x', 'pix']];
  assert.deepEqual(shortestPath(edges, 'pix', new Set(['cartao'])), ['pix', 'fatura', 'cartao']);
  // se o agente já passou por um nó, a ponte prefere chegar nele
  assert.deepEqual(shortestPath(edges, 'pix', new Set(['cartao', 'fatura'])), ['pix', 'fatura']);
  assert.equal(shortestPath([['a', 'b']], 'a', new Set(['z'])), null);
});
