// ETL: reclamações finalizadas do consumidor.gov.br (dados abertos) -> seed/cgov.json
//
//   node scripts/build-seed.mjs caminho/finalizadas_2026-09.csv [outro-mes.csv ...]
//
// Baixe os CSVs mensais em https://www.consumidor.gov.br/pages/dadosabertos/externo/
// ("Dados - <Mês>/<Ano>", um .zip com um CSV separado por ';', UTF-8 com BOM).
// O grafo sai direto do dado: cada Assunto vira um TEMA, cada Problema vira um
// PROBLEMA e cada par (Assunto, Problema) vira uma aresta cujo peso é o número
// real de reclamações. Nada é inventado aqui; seed/curadoria.json só acrescenta
// nome curto e sinônimos de busca.
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SEED_DIR = path.join(HERE, '..', 'seed');
const AREA = process.env.AREA || 'Serviços Financeiros';
const COMPANY = new RegExp(process.env.COMPANY_MATCH || 'picpay', 'i');
const COMPANY_LABEL = process.env.COMPANY_LABEL || 'PicPay';

export const slug = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 56).replace(/-$/, '');

// a fonte traz "?" no lugar do travessão em alguns rótulos
const clean = s => s.trim().replace(/\s+\?\s+/g, ' – ').replace(/\s+/g, ' ');

// nome curto automático quando a curadoria não define um
export function autoShort(label) {
  let s = label.split(/ \/ | \(| – /)[0].trim();
  const first = s.split(',')[0].trim();
  if (s.length > 30 && first.length >= 12) s = first;
  return s.length > 30 ? s.slice(0, 29).trimEnd() + '…' : s;
}

async function main() {
  const files = process.argv.slice(2);
  if (!files.length) { console.error('uso: node scripts/build-seed.mjs <finalizadas_AAAA-MM.csv> [...]'); process.exit(1); }
  const cur = JSON.parse(fs.readFileSync(path.join(SEED_DIR, 'curadoria.json'), 'utf8'));

  const temas = new Map(), probs = new Map(), pairs = new Map();
  const bump = (m, k, isCo, extra) => { const o = m.get(k) || { w: 0, wCompany: 0, ...extra }; o.w++; if (isCo) o.wCompany++; m.set(k, o); return o; };
  let total = 0, inArea = 0, company = 0, minDate = '9999', maxDate = '0000';

  for (const file of files) {
    const rl = readline.createInterface({ input: fs.createReadStream(file, { encoding: 'utf8' }) });
    let head = null;
    for await (const line of rl) {
      if (!head) { head = line.replace(/^﻿/, '').split(';').map(h => h.trim()); continue; }
      const c = line.split(';');
      if (c.length !== head.length) continue;
      total++;
      const r = Object.fromEntries(head.map((h, i) => [h, c[i]]));
      if (r['Área'].trim() !== AREA) continue;
      inArea++;
      const isCo = COMPANY.test(r['Nome Fantasia']);
      if (isCo) company++;
      const d = r['Data Finalização']; if (d < minDate) minDate = d; if (d > maxDate) maxDate = d;
      const tema = clean(r['Assunto']), prob = clean(r['Problema']), grupo = clean(r['Grupo Problema']);
      bump(temas, tema, isCo);
      const p = bump(probs, prob, isCo, { grupos: {} });
      p.grupos[grupo] = (p.grupos[grupo] || 0) + 1;
      bump(pairs, tema + '\u0000' + prob, isCo);
    }
  }

  const src = { id: 'cgov' };
  const node = (kind, label, o, extra = {}) => ({
    _id: `${kind === 'tema' ? 'tema' : 'prob'}:${slug(label)}`, kind, label,
    short: cur.short[label] || autoShort(label),
    keywords: cur.keywords[label] || '',
    w: o.w, wCompany: o.wCompany, src: src.id, ...extra,
  });
  const nodes = [
    ...[...temas].map(([l, o]) => node('tema', l, o)),
    ...[...probs].map(([l, o]) => node('problema', l, o, { group: Object.entries(o.grupos).sort((a, b) => b[1] - a[1])[0][0] })),
  ];
  const ids = new Set(nodes.map(n => n._id));
  if (ids.size !== nodes.length) throw new Error('colisão de _id — aumente o tamanho do slug');
  const edges = [...pairs].map(([k, o]) => {
    const [tema, prob] = k.split('\u0000');
    return { ends: [`tema:${slug(tema)}`, `prob:${slug(prob)}`], rel: 'TEM_PROBLEMA', w: o.w, wCompany: o.wCompany, src: src.id };
  });

  const out = {
    meta: {
      id: 'cgov', name: 'consumidor.gov.br — Dados Abertos (Senacon / MJSP)',
      url: 'https://www.consumidor.gov.br/pages/dadosabertos/externo/',
      what: `Reclamações finalizadas, área "${AREA}"`,
      period: { from: minDate, to: maxDate }, files: files.map(f => path.basename(f)),
      rows: { total, inArea, company }, company: COMPANY_LABEL,
      generatedAt: new Date().toISOString().slice(0, 10),
    },
    nodes: nodes.sort((a, b) => b.w - a.w),
    edges: edges.sort((a, b) => b.w - a.w),
  };
  fs.writeFileSync(path.join(SEED_DIR, 'cgov.json'), JSON.stringify(out, null, 1));
  console.log(`cgov.json: ${temas.size} temas, ${probs.size} problemas, ${edges.length} arestas | ${inArea} reclamações (${company} ${COMPANY_LABEL}) de ${total} lidas | ${minDate}..${maxDate}`);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main();
