// Servidor de referência do grafo de memória do Hugin.
//
//   POST /api/consult { sessionId?, text }          o cliente falou  -> ancora no tema, prioriza, detecta mudança de tema
//   POST /api/visit   { sessionId, nodeId, status? } o agente (ou um clique) navegou até um nó -> abre as relações dele
//   GET  /api/meta                                   regra, fontes e tamanho da base
//
// As duas rotas POST devolvem { sessionId, view, trace, shift }:
//   view  = o subgrafo que deve estar na tela agora (nunca a base inteira)
//   trace = a ordem em que os nós acendem neste passo [{ node, via, why }]
//   shift = { from, to, bridge, kind } quando a conversa mudou de tema
import express from 'express';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { connect, seed, searchNodes, neighborsOf, reach, edgesAmong, nodesById, stats } from './db.mjs';
import { RULE, prioritize, decideTheme, decideEntry, freqOf, prune, shortestPath } from './rank.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(HERE, '..');
const PORT = Number(process.env.PORT) || 4777;
const STATUS = new Set(['consultado', 'descartado', 'confirmado', 'resolvido']);
const OWNED_VOTE = 0.6;   // peso do voto de um nó que pertence a um único tema (ex.: causa do Pix)
const PROBLEM_VOTE = 0.45; // peso do voto de um problema que existe em vários temas, repartido pela frequência real
const MIN_TEXT = 1;       // textScore mínimo do Mongo para um nó contar como citado

const { db, ephemeral } = await connect();
await seed(db, { force: ephemeral || process.env.SEED === 'force' });
const META = await stats(db);

// ---------------------------------------------------------------- sessão
// ponytail: sessões na memória do processo (teto de 500). Com mais de uma instância,
// mover para uma coleção `sessions` com índice TTL.
const sessions = new Map();
function sessionOf(id) {
  if (sessions.has(id)) return sessions.get(id);
  const s = { id: randomUUID(), turn: 0, theme: null, focus: null, rel: new Map(), touched: new Map(), open: new Map(), pinned: [], path: [], past: [],
    state: 'frio', evid: new Map(), hints: [], cands: [], asks: 0 };   // antes do grafo: evidência acumulada e hipóteses
  sessions.set(s.id, s);
  if (sessions.size > 500) sessions.delete(sessions.keys().next().value);
  return s;
}

const isTema = id => id.startsWith('tema:');
const pairKey = (a, b) => (a < b ? a + '|' + b : b + '|' + a);

// ---------------------------------------------------------------- tema
/** Entra num tema. Se já havia outro, é mudança de mundo: acha a ponte e recolhe o tema antigo. */
async function enterTheme(s, theme) {
  const old = s.theme;
  if (old === theme) return { steps: [], shift: null };
  let steps = [{ node: theme, via: null, why: 'tema' }], shift = null;
  if (old) {
    // ponte = menor caminho do tema novo até algo que a conversa já conhecia
    const known = new Set([old, s.focus, ...s.touched.keys()].filter(id => id && id !== theme));
    const found = shortestPath(await reach(db, theme), theme, known);
    const pathIn = found ? found.reverse() : [theme];             // do conhecido até o tema novo
    const bridge = pathIn.filter(id => id !== theme && id !== old);
    const visited = [...s.touched.values()].filter(t => t.theme === old).length;
    s.past = [{ theme: old, visited }, ...s.past.filter(p => p.theme !== theme && p.theme !== old)].slice(0, RULE.MAX_PAST_THEMES);
    s.pinned = bridge;
    s.path = pathIn;
    steps = pathIn.map((id, i) => ({ node: id, via: pathIn[i - 1] ?? null, why: id === theme ? 'novo-tema' : 'ponte' }));
    shift = { from: old, to: theme, bridge, kind: found ? 'ponte' : 'salto' };
  }
  s.theme = theme;
  s.state = 'ancorado';
  s.open = new Map([[theme, RULE.K_ANCHOR]]);   // o mundo antigo fecha; o novo abre com os K mais prioritários
  s.focus = theme;
  return { steps, shift };
}

/** Tema de um nó: ele mesmo, o tema dono (camada de um mundo só) ou o tema em que o problema é mais frequente. */
async function temaOf(id) {
  if (isTema(id)) return id;
  const [node] = await nodesById(db, [id]);
  if (node?.tema) return node.tema;
  const temas = (await neighborsOf(db, id)).filter(n => isTema(n.id)).sort((a, b) => (b.edge.w || 0) - (a.edge.w || 0));
  return temas[0]?.id || null;
}

// ---------------------------------------------------------------- turnos
/** O cliente falou. */
/**
 * Hipóteses de tema enquanto a demanda não foi entendida, em ordem de nota:
 * evidência das falas + pistas do perfil. Sem nenhuma das duas, o mapa geral da base (temas mais frequentes).
 */
async function candidates(s) {
  const by = new Map();
  for (const [id, v] of s.evid) by.set(id, { id, score: v, why: 'fala' });
  for (const h of s.hints) {
    const c = by.get(h.tema) || { id: h.tema, score: 0, why: 'perfil' };
    by.set(h.tema, { ...c, score: Math.min(1, c.score + RULE.HINT_VOTE), hint: h.label });
  }
  const list = [...by.values()].filter(c => c.score >= RULE.AMBIG_FLOOR).sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
  if (list.length) return list.slice(0, RULE.MAX_CANDIDATES).map(c => ({ ...c, score: Math.round(c.score * 100) / 100 }));
  return META.topTemas.map(t => ({ id: t._id, score: 0, why: 'base' }));
}

/** O cliente falou (ou chegou sem dizer nada: text vazio). */
async function consult(s, text, hints) {
  s.turn++;
  if (hints) {                                             // pistas do perfil: valem para a conversa toda
    s.hints = [];
    for (const h of hints) { const tema = await temaOf(h.node); if (tema) s.hints.push({ tema, label: h.label }); }
  }
  const hits = text ? (await searchNodes(db, text.replace(/["-]/g, ' '))).filter(h => h.score >= MIN_TEXT) : [];
  const top = hits[0]?.score || 1;
  const relBefore = s.rel;
  s.rel = new Map(hits.map(h => [h._id, h.score / top]));

  // nota de entrada de cada tema: o tema nomeado (com desempate pela frequência real) ou o tema dono do nó citado
  const entry = new Map();
  const vote = (id, v) => entry.set(id, Math.max(entry.get(id) || 0, v));
  for (const h of hits) {
    const rel = h.score / top;
    const prior = h.w ? Math.log1p(h.w) / Math.log1p(META.maxTemaW) : 0.5;
    if (h.kind === 'tema') vote(h._id, rel * (1 - RULE.PRIOR_WEIGHT + RULE.PRIOR_WEIGHT * prior));
    else if (h.tema) vote(h.tema, rel * OWNED_VOTE);
  }
  // problema que existe em vários temas ("não consigo pagar"): vota nos temas em que ele é mais frequente
  for (const h of hits.slice(0, 3)) {
    if (h.kind === 'tema' || h.tema) continue;
    const temas = (await neighborsOf(db, h._id)).filter(n => isTema(n.id));
    const maxW = Math.max(1, ...temas.map(n => n.edge.w || 0));
    for (const n of temas) vote(n.id, (h.score / top) * PROBLEM_VOTE * freqOf(n.edge, maxW));
  }

  let theme;
  if (s.theme) {
    theme = decideTheme(s.theme, [...entry].map(([id, score]) => ({ id, score }))).theme;
  } else {
    // ainda sem tema: a evidência soma entre as falas, e a demanda só entra no grafo quando há um vencedor claro
    for (const [id, v] of s.evid) s.evid.set(id, v * RULE.EVID_DECAY);
    for (const [id, v] of entry) s.evid.set(id, Math.min(1, (s.evid.get(id) || 0) + v));
    for (const [id, v] of relBefore) s.rel.set(id, Math.max(s.rel.get(id) || 0, v * RULE.EVID_DECAY));
    s.cands = await candidates(s);
    const d = decideEntry(s.cands, s.asks);
    s.state = d.state;
    if (d.state !== 'ancorado') { s.asks++; return { trace: [], shift: null }; }
    theme = d.theme;
    s.forced = !!d.forced;
  }
  s.state = 'ancorado';

  const { steps, shift } = await enterTheme(s, theme);
  const view = await buildView(s);
  const said = view.nodes.filter(n => n.role === 'foco' && n.parent === theme).map(n => ({ node: n.id, via: theme, why: 'cliente' }));
  return { trace: [...steps, ...said], shift, view };
}

/** O agente (ou um clique) navegou até um nó. */
async function visit(s, nodeId, status) {
  if (nodeId.startsWith('more:')) {                       // "+N": mostra a próxima leva de vizinhos
    const parent = nodeId.slice(5);
    if (s.open.has(parent)) s.open.set(parent, s.open.get(parent) + (parent === s.theme ? RULE.K_ANCHOR : RULE.K_VISIT));
    return { trace: [], shift: null };
  }
  const [node] = await nodesById(db, [nodeId]);
  if (!node) throw Object.assign(new Error('nó não encontrado'), { status: 404 });

  if (node.kind === 'tema') {                             // atravessou uma porta: muda de mundo navegando
    const { steps, shift } = await enterTheme(s, nodeId);
    return { trace: steps, shift };
  }
  if (!s.theme) {                                         // primeira ação da sessão foi um clique, não uma mensagem
    const tema = await temaOf(nodeId);
    if (!tema) throw Object.assign(new Error('nó sem tema'), { status: 404 });
    await enterTheme(s, tema);
  }

  // por onde o agente chegou: o foco atual, senão o nó aberto mais recente que seja vizinho
  const around = new Set((await neighborsOf(db, nodeId)).map(n => n.id));
  const via = [s.focus, ...[...s.open.keys()].reverse(), ...s.pinned].find(id => around.has(id)) || null;
  s.touched.set(nodeId, { turn: s.turn, status, theme: s.theme, via });
  if (status === 'consultado') s.open.set(nodeId, RULE.K_VISIT);   // consultar abre as relações do nó
  else s.open.delete(nodeId);                                     // descartar/confirmar/resolver fecha
  s.focus = nodeId;
  return { trace: [{ node: nodeId, via, why: status }], shift: null };
}

// ---------------------------------------------------------------- o que vai para a tela
async function buildView(s) {
  if (!s.theme) {
    // demanda ainda não entendida: em vez do grafo, as hipóteses (ou o mapa geral, se não há pista nenhuma)
    const docs = new Map((await nodesById(db, s.cands.map(c => c.id))).map(d => [d._id, d]));
    const nodes = s.cands.filter(c => docs.has(c.id)).map(c => {
      const d = docs.get(c.id);
      return { id: d._id, kind: d.kind, label: d.label, short: d.short, w: d.w, wCompany: d.wCompany, src: d.src,
        role: c.why === 'base' ? 'mapa' : 'hipotese', p: c.score, why: c.why, hint: c.hint };
    });
    return {
      nodes, links: [], mesh: [], theme: null, past: [], turn: s.turn, state: s.state,
      // o que perguntar: aberta quando não há pista; dirigida (entre as opções) quando há hipóteses
      ask: { open: s.state === 'frio', options: s.state === 'frio' ? [] : nodes.slice(0, 3).map(n => n.short), asked: s.asks, handoff: s.state === 'frio' && s.asks > RULE.MAX_ASKS },
      stats: { visible: nodes.length, hidden: 0, total: META.nodes, edges: META.edges },
    };
  }
  const inc = new Map();
  const put = (id, o) => inc.set(id, { ...inc.get(id), ...o });
  const hiddenBy = new Map();
  const structural = new Set([s.theme, ...s.pinned, ...s.past.map(p => p.theme)]);

  // 1. cada nó aberto mostra só os K vizinhos de maior prioridade
  for (const [openId, k] of s.open) {
    const { shown, hidden } = prioritize(await neighborsOf(db, openId), { rel: s.rel, touched: s.touched, turn: s.turn, k, exclude: structural });
    for (const n of shown) if (!inc.has(n.id)) put(n.id, { role: n.factors.rel >= RULE.FOCUS_REL ? 'foco' : 'vizinho', p: n.p, factors: n.factors, parent: openId });
    hiddenBy.set(openId, hidden);
  }
  // 2. papéis protegidos: trilha (o que o agente consultou neste tema), ponte, âncora e contexto anterior
  for (const [id, t] of s.touched) if (t.theme === s.theme) put(id, { role: 'trilha', status: t.status, parent: inc.get(id)?.parent || t.via });
  for (const id of s.pinned) put(id, { role: 'ponte', status: s.touched.get(id)?.status });
  put(s.theme, { role: 'ancora', parent: undefined });
  for (const p of s.past) put(p.theme, { role: 'contexto', visited: p.visited, parent: undefined });

  // 3. teto de nós: sai primeiro o vizinho de menor prioridade, e ele volta para o "+N" de quem o revelou
  const { dropped } = prune([...inc].map(([id, o]) => ({ id, role: o.role, p: o.p || 0 })), RULE.MAX_VISIBLE);
  for (const id of dropped) { const parent = inc.get(id).parent; hiddenBy.set(parent, (hiddenBy.get(parent) || 0) + 1); inc.delete(id); }

  const ids = [...inc.keys()];
  const [docs, real] = await Promise.all([nodesById(db, ids), edgesAmong(db, ids)]);
  const edgeOf = new Map(real.map(e => [pairKey(...e.ends), e]));
  const nodes = docs.map(d => ({
    id: d._id, kind: d.kind, label: d.label, short: d.short, group: d.group, w: d.w, wCompany: d.wCompany,
    src: d.src, ref: d.ref, detail: d.detail, ...inc.get(d._id),
  }));

  // 4. ligações: só as estruturais (quem revelou quem + a ponte). As demais relações reais ficam fora da tela.
  const links = new Map();
  const link = (a, b) => {
    if (!a || !b || a === b || !inc.has(a) || !inc.has(b)) return;
    const e = edgeOf.get(pairKey(a, b));
    links.set(pairKey(a, b), e ? { source: a, target: b, rel: e.rel, w: e.w, wCompany: e.wCompany, p: e.p, src: e.src, note: e.note } : { source: a, target: b, rel: 'SALTO', src: 'salto' });
  };
  for (const [id, o] of inc) link(o.parent, id);
  for (let i = 1; i < s.path.length; i++) link(s.path[i - 1], s.path[i]);
  const linked = new Set([...links.values()].flatMap(l => [l.source, l.target]));
  for (const id of ids) {                                  // ninguém fica solto: usa uma aresta real, senão marca o salto
    if (linked.has(id) || id === s.theme) continue;
    const mine = real.filter(e => e.ends.includes(id));
    const e = mine.find(e => e.ends.some(x => s.path.includes(x))) || mine[0];   // prefere se ligar à ponte
    link(id, e ? e.ends.find(x => x !== id) : s.theme);
  }
  // 5. "+N": o que cada nó aberto ainda esconde
  let hidden = 0;
  for (const [parent, n] of hiddenBy) {
    if (!n || !inc.has(parent)) continue;
    hidden += n;
    nodes.push({ id: 'more:' + parent, kind: 'more', short: '+' + n, count: n, parent, role: 'vizinho' });
    links.set('more:' + parent, { source: parent, target: 'more:' + parent, rel: 'MAIS', src: 'more' });
  }
  // 6. malha: as demais relações reais entre nós visíveis. A árvore ignora; o modo "rede" desenha bem fraco.
  const mesh = real.filter(e => !links.has(pairKey(...e.ends))).map(e => ({ source: e.ends[0], target: e.ends[1], w: e.w, p: e.p, src: e.src }));
  return {
    nodes, links: [...links.values()], mesh, theme: s.theme, turn: s.turn, state: 'ancorado', forced: s.forced || undefined,
    past: s.past.map(p => p.theme),
    stats: { visible: ids.length, hidden, total: META.nodes, edges: META.edges },
  };
}

// ---------------------------------------------------------------- http
const app = express();
app.use(express.json({ limit: '10kb' }));

const str = (v, max) => typeof v === 'string' && v.length > 0 && v.length <= max;   // strings só: nada de operador Mongo vindo do cliente
const bad = msg => Object.assign(new Error(msg), { status: 400 });

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/meta', (_req, res) => res.json({
  rule: RULE, sources: META.sources, db: ephemeral ? 'mongod efêmero (mongodb-memory-server)' : 'MONGODB_URI',
  stats: { nodes: META.nodes, edges: META.edges, byKind: META.byKind },
}));
app.post('/api/consult', async (req, res) => {
  const { sessionId, text = '', hints } = req.body || {};
  if (typeof text !== 'string' || text.length > 500) throw bad('text: string de até 500 caracteres (vazia = cliente chegou sem dizer nada)');
  if (hints !== undefined && !(Array.isArray(hints) && hints.length <= 8 && hints.every(h => h && str(h.node, 120) && (h.label === undefined || str(h.label, 80)))))
    throw bad('hints: até 8 itens { node, label? }');
  const s = sessionOf(typeof sessionId === 'string' ? sessionId : null);
  const out = await consult(s, text.trim(), hints);
  res.json({ sessionId: s.id, ...out, view: out.view || await buildView(s) });
});
app.post('/api/visit', async (req, res) => {
  const { sessionId, nodeId, status = 'consultado' } = req.body || {};
  if (!str(nodeId, 120)) throw bad('nodeId: string');
  if (!STATUS.has(status)) throw bad('status: ' + [...STATUS].join(' | '));
  const s = sessionOf(typeof sessionId === 'string' ? sessionId : null);
  const out = await visit(s, nodeId, status);
  res.json({ sessionId: s.id, ...out, view: await buildView(s) });
});

// a página e o módulo do grafo (mesma origem da API)
app.get('/', (_req, res) => res.sendFile(path.join(ROOT, 'hugin-demo.html')));
app.get('/hugin-graph.js', (_req, res) => res.sendFile(path.join(ROOT, 'hugin-graph.js')));
app.get('/vendor/force-graph.min.js', (_req, res) => res.sendFile(path.join(HERE, 'node_modules', 'force-graph', 'dist', 'force-graph.min.js')));

app.use((err, _req, res, _next) => {
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'erro interno' });
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`Hugin · grafo de memória em http://localhost:${PORT}`);
  console.log(`MongoDB: ${ephemeral ? 'mongod efêmero (defina MONGODB_URI para usar o seu)' : 'MONGODB_URI'} · ${META.nodes} nós, ${META.edges} arestas`);
});
